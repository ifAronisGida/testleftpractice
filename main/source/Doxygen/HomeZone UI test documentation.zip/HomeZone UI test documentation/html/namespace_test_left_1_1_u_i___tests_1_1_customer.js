var namespace_test_left_1_1_u_i___tests_1_1_customer =
[
    [ "TcCustomerTest", "class_test_left_1_1_u_i___tests_1_1_customer_1_1_tc_customer_test.html", "class_test_left_1_1_u_i___tests_1_1_customer_1_1_tc_customer_test" ]
];