var class_ui_tests_1_1_settings_1_1_tc_bend_settings_test =
[
    [ "AppSettingsConfigurationTest", "class_ui_tests_1_1_settings_1_1_tc_bend_settings_test.html#a710ac58de4b6dee479882509e91f1863", null ],
    [ "BendDeductionConfigurationTest", "class_ui_tests_1_1_settings_1_1_tc_bend_settings_test.html#a59cd887328ddc08134a468d0e8245c82", null ],
    [ "OpenAndCloseDataManagerBendTest", "class_ui_tests_1_1_settings_1_1_tc_bend_settings_test.html#a6411efeef26e1c3e6686d717512d8466", null ],
    [ "ToolsConfigurationTest", "class_ui_tests_1_1_settings_1_1_tc_bend_settings_test.html#a2b132c9981e342ae1e65883498f0ac12", null ]
];