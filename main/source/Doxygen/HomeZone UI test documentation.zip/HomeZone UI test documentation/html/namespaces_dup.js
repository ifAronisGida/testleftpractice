var namespaces_dup =
[
    [ "TestLeft", "namespace_test_left.html", "namespace_test_left" ]
];