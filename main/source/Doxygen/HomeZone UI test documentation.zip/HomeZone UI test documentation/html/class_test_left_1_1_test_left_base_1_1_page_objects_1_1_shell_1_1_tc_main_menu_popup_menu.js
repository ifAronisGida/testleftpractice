var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu =
[
    [ "About", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a392366eda1e4d0a21d9b7184b63979cf", null ],
    [ "Exit", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a152d8c4fb75919e93586cdae60e9bf83", null ],
    [ "Help", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a27be6f5c9a4ba97b98dcdccbf3d8195c", null ],
    [ "Refresh", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a2910b0d6a03e68b8a4d6b1f0b3ca66dd", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a9b989ba47d612cb954aa176a518bd611", null ],
    [ "Settings", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a5b9abfeac62fd55535bbb95869cc1cd3", null ],
    [ "WelcomeScreen", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a446783a1312a12f49f5cac7132fd6bbc", null ]
];