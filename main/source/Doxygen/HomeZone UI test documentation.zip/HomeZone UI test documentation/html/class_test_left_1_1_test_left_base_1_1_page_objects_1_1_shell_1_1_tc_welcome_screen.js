var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html#a4ca398d549ff23a6ad7e79abe2d23031", null ],
    [ "ShowWelcomeScreen", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html#afa1e937a36192de26d473179ae369f90", null ]
];