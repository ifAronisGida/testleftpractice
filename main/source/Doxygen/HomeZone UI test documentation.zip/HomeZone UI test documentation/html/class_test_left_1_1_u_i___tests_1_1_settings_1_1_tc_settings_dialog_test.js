var class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_settings_dialog_test =
[
    [ "OpenAndCloseSettingsTest", "class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_settings_dialog_test.html#a40a8ed62670c5792eb87621df237e397", null ]
];