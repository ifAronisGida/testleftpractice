var class_ui_tests_1_1_cut_1_1_tc_cut_test =
[
    [ "CutOpenCloseTest", "class_ui_tests_1_1_cut_1_1_tc_cut_test.html#a30708d9df5026d842c527fdfbc2e40bf", null ],
    [ "DoCutOpenClose", "class_ui_tests_1_1_cut_1_1_tc_cut_test.html#a57518d81be2344bd3c8f00fbb629d0b3", null ]
];