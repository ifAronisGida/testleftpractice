var class_test_left_1_1_u_i___tests_1_1_design_1_1_tc_design_test =
[
    [ "DesignOpenCloseTest", "class_test_left_1_1_u_i___tests_1_1_design_1_1_tc_design_test.html#a957b2f28bb25133906b7fdc25b5c37b2", null ]
];