var namespace_test_left_1_1_u_i___tests =
[
    [ "Base", "namespace_test_left_1_1_u_i___tests_1_1_base.html", "namespace_test_left_1_1_u_i___tests_1_1_base" ],
    [ "Customer", "namespace_test_left_1_1_u_i___tests_1_1_customer.html", "namespace_test_left_1_1_u_i___tests_1_1_customer" ],
    [ "Cut", "namespace_test_left_1_1_u_i___tests_1_1_cut.html", "namespace_test_left_1_1_u_i___tests_1_1_cut" ],
    [ "CutJob", "namespace_test_left_1_1_u_i___tests_1_1_cut_job.html", "namespace_test_left_1_1_u_i___tests_1_1_cut_job" ],
    [ "Design", "namespace_test_left_1_1_u_i___tests_1_1_design.html", "namespace_test_left_1_1_u_i___tests_1_1_design" ],
    [ "Flux", "namespace_test_left_1_1_u_i___tests_1_1_flux.html", "namespace_test_left_1_1_u_i___tests_1_1_flux" ],
    [ "Machine", "namespace_test_left_1_1_u_i___tests_1_1_machine.html", "namespace_test_left_1_1_u_i___tests_1_1_machine" ],
    [ "Material", "namespace_test_left_1_1_u_i___tests_1_1_material.html", "namespace_test_left_1_1_u_i___tests_1_1_material" ],
    [ "Part", "namespace_test_left_1_1_u_i___tests_1_1_part.html", "namespace_test_left_1_1_u_i___tests_1_1_part" ],
    [ "PartOrder", "namespace_test_left_1_1_u_i___tests_1_1_part_order.html", "namespace_test_left_1_1_u_i___tests_1_1_part_order" ],
    [ "Settings", "namespace_test_left_1_1_u_i___tests_1_1_settings.html", "namespace_test_left_1_1_u_i___tests_1_1_settings" ],
    [ "Shell", "namespace_test_left_1_1_u_i___tests_1_1_shell.html", "namespace_test_left_1_1_u_i___tests_1_1_shell" ],
    [ "Utilities", "namespace_test_left_1_1_u_i___tests_1_1_utilities.html", "namespace_test_left_1_1_u_i___tests_1_1_utilities" ]
];