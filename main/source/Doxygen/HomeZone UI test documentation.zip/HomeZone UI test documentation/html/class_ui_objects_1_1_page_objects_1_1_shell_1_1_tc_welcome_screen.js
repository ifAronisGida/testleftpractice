var class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen =
[
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html#a11374594c7915a8be9a88276ea119e93", null ],
    [ "ShowWelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html#a8e9432e19d2d02d52e19758accbc27c8", null ]
];