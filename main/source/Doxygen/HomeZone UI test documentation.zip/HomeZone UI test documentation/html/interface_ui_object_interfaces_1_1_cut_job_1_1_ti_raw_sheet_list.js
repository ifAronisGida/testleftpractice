var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet_list =
[
    [ "GetRawSheet", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet_list.html#a99325faf3b6d477a5e26c952704c6681", null ],
    [ "Count", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet_list.html#a5c7930ac7ba9218d4d755ae7bf714144", null ]
];