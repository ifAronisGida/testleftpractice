var class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info =
[
    [ "SelectPart", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info.html#acdd571a5d98bf645144b1a063712552b", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info.html#a85250b6372f47865fff13b92e300a155", null ]
];