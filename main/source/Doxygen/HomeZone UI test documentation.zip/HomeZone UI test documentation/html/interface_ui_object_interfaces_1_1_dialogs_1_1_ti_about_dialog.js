var interface_ui_object_interfaces_1_1_dialogs_1_1_ti_about_dialog =
[
    [ "Close", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_about_dialog.html#a7431365eed608d93061465ce9c701112", null ],
    [ "CopyToClipboard", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_about_dialog.html#a8b0e079ce618e2e4bc3ac3c3b5606df8", null ]
];