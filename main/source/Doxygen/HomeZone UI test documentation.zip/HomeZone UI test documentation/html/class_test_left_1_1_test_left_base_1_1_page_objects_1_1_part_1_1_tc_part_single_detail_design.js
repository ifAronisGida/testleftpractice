var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design =
[
    [ "Import", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#a2d741144be002618d708d8a8af2c5767", null ],
    [ "Open", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#a86194831870536015c6862a5e0bd2909", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#a28c15f0c25a43e099e3cb0d6af4d661d", null ]
];