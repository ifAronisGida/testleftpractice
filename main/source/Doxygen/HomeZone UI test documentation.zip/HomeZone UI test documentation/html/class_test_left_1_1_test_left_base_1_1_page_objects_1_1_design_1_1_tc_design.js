var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_design_1_1_tc_design =
[
    [ "TcDesign", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_design_1_1_tc_design.html#a78b656dc1579ce0e3338ee30dbe6fe5f", null ],
    [ "CloseApp", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_design_1_1_tc_design.html#a35311c7bfae698fcba19c06872917c54", null ],
    [ "MainWindowVisible", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_design_1_1_tc_design.html#a5c2b3d648e960a1505a24be15f23456f", null ]
];