var class_ui_tests_1_1_customer_1_1_tc_customer_test =
[
    [ "NewCustomersAndDeleteTest", "class_ui_tests_1_1_customer_1_1_tc_customer_test.html#a394f57e613130ffe9a1f96e3ebebe937", null ]
];