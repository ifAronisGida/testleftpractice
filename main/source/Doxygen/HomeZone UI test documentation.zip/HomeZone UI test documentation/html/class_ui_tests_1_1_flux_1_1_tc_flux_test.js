var class_ui_tests_1_1_flux_1_1_tc_flux_test =
[
    [ "BoostPartSucessTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#a8e467e310457f81299f32550d044a07a", null ],
    [ "BoostSolutionWithErrorTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#a49d371650cf5b4f871a0539960d2f972", null ],
    [ "CloseWithoutSave", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#aa994847ec64d336196b49edbea0dc334", null ],
    [ "ConfigureMachineTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#a6f8f2d2ab5a82ac8b12139d6c93fb9ae", null ],
    [ "DoFluxOpenClose", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#aa3470e7d24fb20c9e6427bcfe137e18f", null ],
    [ "FluxOpenCloseTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#ae290dd7bebda7a7fe0d922b1b00a6a85", null ],
    [ "FluxSaveAndCloseTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#a1cf055ce7f9ac4f586941f1cdf9fd4d5", null ],
    [ "ReleaseBoostedPart", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html#ae528c54505539d1b059b09c25c7ec427", null ]
];