var class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux =
[
    [ "TcFlux", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a3f8c8ad1d9881b0ea66379dff571c5b3", null ],
    [ "ChangeSolution", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a4bb8d6db9df284d32592b63739151eee", null ],
    [ "CloseApp", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a3dc77317eacd0a2b32d97f8ad12bb819", null ],
    [ "IsMainWindowVisible", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a0edc7a4919a17b00c91edb8a2de64e5a", null ],
    [ "SaveAndClosePartInFlux", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html#ab8db309525fff8f6453fa0e2c4228ecf", null ]
];