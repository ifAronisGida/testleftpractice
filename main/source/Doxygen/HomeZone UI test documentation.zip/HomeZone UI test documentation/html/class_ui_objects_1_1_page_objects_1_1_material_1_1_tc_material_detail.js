var class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail =
[
    [ "Abbreviation", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a473f31db1ecf6022c26e45ef076e2396", null ],
    [ "EModulus", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a718b76884d0239113a9e3f0c0c6f0a1b", null ],
    [ "Id", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a9e22efdaad84bf89bfe169883783999e", null ],
    [ "Name", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a08ec1940da728399e1fe3ef77340aed1", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a6c8e1751fbc81d82aa7312ac4d1acd78", null ],
    [ "SpecificWeight", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#abbe2d18129002969f7567133b83913a0", null ],
    [ "TensileStrength", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a4cab63c7392d7ca76ab88544d0a797ab", null ],
    [ "TensileStrengthMax", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a676e1823243d4f3f1275acc1807bcf15", null ],
    [ "TensileStrengthMin", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a4d17b776a77c82d68569208cffaef8e4", null ]
];