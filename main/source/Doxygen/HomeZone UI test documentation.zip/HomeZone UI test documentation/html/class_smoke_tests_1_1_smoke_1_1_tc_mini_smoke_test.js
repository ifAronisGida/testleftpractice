var class_smoke_tests_1_1_smoke_1_1_tc_mini_smoke_test =
[
    [ "EndlessMiniSmokeTest", "class_smoke_tests_1_1_smoke_1_1_tc_mini_smoke_test.html#a5f58e091952de5afeae2cf3bcacb39c5", null ],
    [ "MiniSmokeTest", "class_smoke_tests_1_1_smoke_1_1_tc_mini_smoke_test.html#a85551f2532d0a384ffb1d9bfeb0fddda", null ]
];