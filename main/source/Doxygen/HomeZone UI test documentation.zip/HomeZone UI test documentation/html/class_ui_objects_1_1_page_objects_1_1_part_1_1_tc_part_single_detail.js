var class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail =
[
    [ "OpenCustomerAdministration", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ab684f8f7012b28fdac979bf6b491c0c7", null ],
    [ "WaitForNameEnabled", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a1a6bbb89e1f2a32de5d3e78ccddf06d6", null ],
    [ "DrawingNumber", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#af39f38fd85446e6295c4914ec5467c95", null ],
    [ "DrawingVersion", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#aab33ce6a86dacc734f177b5fb89214bf", null ],
    [ "ExternalName", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a534349422f0dc843f88e58470b08aa41", null ],
    [ "IdTextEdit", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a76a777f4ae0e30049492f5f4abd0a9ad", null ],
    [ "Name", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#afa0501402d5f29d3ce88beb18a87b74e", null ],
    [ "Note", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#afe3364305246a1794b6db1bac56e2db7", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a0178c4a2936df73bb73d0a795967c3ee", null ],
    [ "Archivable", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ae840a813acb8b02c1f2e93d01575f4b4", null ],
    [ "Customer", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a1cd82be297feadbf19db28b779c708b5", null ],
    [ "Id", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ae217210a80dab14d8146a726370207f0", null ],
    [ "IsMoreExpanded", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ad0773d5158a2e154d79eae45bd18060e", null ]
];