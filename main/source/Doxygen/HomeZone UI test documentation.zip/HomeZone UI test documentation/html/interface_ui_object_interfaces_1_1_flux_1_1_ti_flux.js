var interface_ui_object_interfaces_1_1_flux_1_1_ti_flux =
[
    [ "ChangeSolution", "interface_ui_object_interfaces_1_1_flux_1_1_ti_flux.html#a834eaabfb8d7cf8507b79c3ddc59eff1", null ],
    [ "SaveAndClosePartInFlux", "interface_ui_object_interfaces_1_1_flux_1_1_ti_flux.html#a6af712935fa539c9c38534fb45300ca2", null ]
];