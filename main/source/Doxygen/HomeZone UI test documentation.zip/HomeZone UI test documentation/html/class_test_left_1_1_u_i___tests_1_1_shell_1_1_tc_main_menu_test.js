var class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test =
[
    [ "ExitTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#a6b049d25cf2e64ca3b7c756edbbb0258", null ],
    [ "OpenAndCloseSettingsTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#a82ac63d7bbc1d829b5453809e7f5eeac", null ],
    [ "RefreshMasterDataTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#afc91b83be714001992d72f954e2c96a6", null ],
    [ "ShowAboutTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#a20716ee0643a72c37f6677efac81c8c5", null ],
    [ "ShowHelpTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#a69dab5b9c247dc894d6f62dba58ddeef", null ],
    [ "ShowWelcomeScreenTest", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#aaa8ad99e997004eb287a4496af99c54f", null ]
];