var interface_ui_object_interfaces_1_1_common_1_1_ti_domain =
[
    [ "Goto", "interface_ui_object_interfaces_1_1_common_1_1_ti_domain.html#adab26a4a6674d1631b0fc4de10b8f176", null ],
    [ "ResultColumn", "interface_ui_object_interfaces_1_1_common_1_1_ti_domain.html#a55ec64a3673b0da7233d638014a6d50d", null ]
];