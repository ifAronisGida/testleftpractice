var class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row =
[
    [ "TcCutJobOrderRow", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a43c4df12d07f711cb38960618efcaec8", null ],
    [ "AngularPositions", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a476a516d45d69932ae8c4dccaffe6f03", null ],
    [ "Customer", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a8066aaa47c86212bfad9465994e6ebe4", null ],
    [ "CuttingProgram", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ac7f1cb4ae7fb5905075830794e1de5f3", null ],
    [ "DistanceMode", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#aa684ec9f278f48f6077f3a6ecf8e0858", null ],
    [ "DrawingButton", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a6195afd9c9df73590356ad125365ca3c", null ],
    [ "IgnoreProcessings", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ade4998c37646148651b2349dfa318244", null ],
    [ "Note", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ac295dccc4472c1e3e7b75fdc331e22fd", null ],
    [ "OrderLink", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#aeab75e1fca97cfe794ef413f836149c6", null ],
    [ "PartLink", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a8ec608ca98e288a4c55cadfbd3fa2fd4", null ],
    [ "NestingPriority", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ae14b52e6f0f13853299dfb0c083d620c", null ],
    [ "Pending", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#acd98db9ffff8c73e66209fec0f9a3b2c", null ],
    [ "SamplePartsCount", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a8282728d956b5aa16d00df1653f508cd", null ],
    [ "TargetDate", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a2b1d6e94888c104fb18b263711422215", null ],
    [ "Total", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a2d4651fe115bc64d7391f5d9df678e0e", null ]
];