var class_test_left_1_1_u_i___tests_1_1_customer_1_1_tc_customer_test =
[
    [ "NewCustomersAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_customer_1_1_tc_customer_test.html#a8393a8d7dacd14668b08246b8ef6ac65", null ]
];