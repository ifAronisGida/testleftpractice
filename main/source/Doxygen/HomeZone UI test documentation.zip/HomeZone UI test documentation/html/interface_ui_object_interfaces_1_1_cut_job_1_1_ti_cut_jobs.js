var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs =
[
    [ "BaseInfo", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs.html#a786b5797d15fc490a96eeab0cf1bb615", null ],
    [ "ContainedOrders", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs.html#a62c1002957c0146fd3dab832eee81263", null ],
    [ "SheetProgram", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs.html#abc680eedc1e328f6e2ac94b9354abd07", null ],
    [ "Toolbar", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs.html#ac2967d73ecb193147094df357281f91b", null ]
];