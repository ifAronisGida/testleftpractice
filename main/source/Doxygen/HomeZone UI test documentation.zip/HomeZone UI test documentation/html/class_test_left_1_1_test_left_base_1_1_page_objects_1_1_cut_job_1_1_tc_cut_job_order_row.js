var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row =
[
    [ "TcCutJobOrderRow", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a9c92964de45fab5a6788dcf1aaca8602", null ],
    [ "AngularPositions", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a3c5c801819bcc3cc63ee944cf776ca7b", null ],
    [ "Customer", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ae03721dd65c07805f9547a3ca435e06c", null ],
    [ "CuttingProgram", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#aed5ed87272334e04165fb2b77a8cb738", null ],
    [ "DistanceMode", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ad595f92a4f82abd1a9c965b9fd0b03e6", null ],
    [ "DrawingButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#acdd64241b0afcfa8913f7ac856afe551", null ],
    [ "IgnoreProcessings", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a82e7de594399821b12329c714a096c0f", null ],
    [ "Note", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a049b861578dda0505e1f594ac847ceab", null ],
    [ "OrderLink", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#acfb27363ba4e67978a04a8edfc1d7354", null ],
    [ "PartLink", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ac807cef33f02e5c0442c79d07d42a122", null ],
    [ "NestingPriority", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ae6176b7f84e888e9881c6d2547d921f3", null ],
    [ "Pending", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a74a23df8b0c3b6f0fcdf9862a48b59d4", null ],
    [ "SamplePartsCount", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a90933053a9d47c834c05e227fdfee313", null ],
    [ "TargetDate", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#a0a16e1260f27fe23fc5a9fc210aadf72", null ],
    [ "Total", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html#ace6cdcdb35fecc27c6fa7142d37d91d8", null ]
];