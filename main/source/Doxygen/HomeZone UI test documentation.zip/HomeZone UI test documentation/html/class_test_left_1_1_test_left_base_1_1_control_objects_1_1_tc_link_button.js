var class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_link_button =
[
    [ "Label", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_link_button.html#ab5af80e5715a54c52787a87913e23914", null ]
];