var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row =
[
    [ "AngularPositions", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a407ba20cb1e8e7b34ee2fc3500106211", null ],
    [ "Customer", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a74402cdc0fd895b30342c1e143bd9403", null ],
    [ "CuttingProgram", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a49a5d7d3577c4bf3f1f5ba0560834186", null ],
    [ "DistanceMode", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a683136411ce382378bd80a0904d55420", null ],
    [ "DrawingButton", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a651e18bb6a22559308f81acfb344e6aa", null ],
    [ "IgnoreProcessings", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a986329b49deeff38ab9db80a6e6a0446", null ],
    [ "NestingPriority", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a184497ce96e555b14c9e799853340d0b", null ],
    [ "Note", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a1bc3e27aabcee0b4e6b9c00856e95e6b", null ],
    [ "OrderLink", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a97262aaf4e148a194cf7784f85d20cf3", null ],
    [ "PartLink", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a90eb8443fe3fc7444587eff42ef42882", null ],
    [ "Pending", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a62a51c6283eb9f3a07e80cec0d7e54a2", null ],
    [ "SamplePartsCount", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a0aeec0b3706579fa441c38d069c98c4e", null ],
    [ "TargetDate", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a3188fd462b3263a63cca78f7dba25645", null ],
    [ "Total", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html#a1f9b34f61e5f6c8c0a69dca814ebdaf1", null ]
];