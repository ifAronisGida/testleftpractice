var class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar =
[
    [ "Delete", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a58fa1c922e04a03a9e07cf2249fc7629", null ],
    [ "Duplicate", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a94cdac2afe55405407c7076fdd752fbd", null ],
    [ "New", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#af4dabe18f2b02d35d37bd0853673bdae", null ],
    [ "Save", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a016030049f368cf7354c8c5ced1affc8", null ],
    [ "CanDelete", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a8885ef678e9a981ef9f8079af10f6bff", null ],
    [ "CanRevert", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#ac23eadd737ba1510de4e89d372798322", null ],
    [ "CanSave", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a3023fdfb388dd0b3f073ac1ecc7c606d", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html#a5efdef63209ab6d0e4af250951484f9a", null ]
];