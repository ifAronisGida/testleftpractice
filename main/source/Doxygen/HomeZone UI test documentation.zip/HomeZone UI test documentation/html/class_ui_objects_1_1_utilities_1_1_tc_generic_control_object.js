var class_ui_objects_1_1_utilities_1_1_tc_generic_control_object =
[
    [ "SearchPattern", "class_ui_objects_1_1_utilities_1_1_tc_generic_control_object.html#aab3322a4504681ec63f2f58e6b81bbac", null ]
];