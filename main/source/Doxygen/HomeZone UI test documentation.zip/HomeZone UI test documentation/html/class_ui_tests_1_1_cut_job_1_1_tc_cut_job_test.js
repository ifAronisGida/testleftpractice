var class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test =
[
    [ "NewCutJobAndDeleteTest", "class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test.html#a24832c0a03db05ccde8be023422ffa76", null ],
    [ "OrdersTableTest", "class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test.html#a05837a75654035c714ed36e92d639f92", null ],
    [ "RawMaterialSelectionTest", "class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test.html#ae51b250cc9b11440ba7a4f3e653e407e", null ],
    [ "RawSheetsTest", "class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test.html#a7afbf456c4d5254ab6b8da1503bc62be", null ]
];