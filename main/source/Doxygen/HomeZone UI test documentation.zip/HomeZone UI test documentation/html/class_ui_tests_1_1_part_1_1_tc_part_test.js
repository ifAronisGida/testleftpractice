var class_ui_tests_1_1_part_1_1_tc_part_test =
[
    [ "ImportDesignTest", "class_ui_tests_1_1_part_1_1_tc_part_test.html#ad6f3c1adb523db6fc31c0ef907afac10", null ],
    [ "ImportPartTest", "class_ui_tests_1_1_part_1_1_tc_part_test.html#abc2455cf1ded38fa4099ec21b3b90715", null ],
    [ "NewPartAndDeleteTest", "class_ui_tests_1_1_part_1_1_tc_part_test.html#ad13cbf4a242b1e651aea943a9b94830b", null ]
];