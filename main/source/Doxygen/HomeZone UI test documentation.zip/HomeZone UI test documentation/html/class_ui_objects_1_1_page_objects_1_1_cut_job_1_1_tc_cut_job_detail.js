var class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail =
[
    [ "FinishDate", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html#aefc49f29a14fa1c8d7fd050d94af7432", null ],
    [ "Id", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html#a634e4fc0b6f09ff76abf2d918ee5611b", null ],
    [ "RawMaterial", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html#ae6c00695e2268b376dbbc01531c7f5e5", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html#ad10bf016e6ab8ffab5e983c23a3d37fa", null ]
];