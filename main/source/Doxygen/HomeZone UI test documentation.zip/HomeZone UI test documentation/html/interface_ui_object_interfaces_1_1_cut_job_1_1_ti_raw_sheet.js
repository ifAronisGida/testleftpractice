var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet =
[
    [ "Delete", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet.html#a5f49fbe3aa7e24e8354ec8910a23e20a", null ],
    [ "Quantity", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet.html#aaafdc61cea08ced60a411396070bb42c", null ],
    [ "RawSheet", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet.html#af82fd05a1db4bc54bd642b3e42b63d90", null ]
];