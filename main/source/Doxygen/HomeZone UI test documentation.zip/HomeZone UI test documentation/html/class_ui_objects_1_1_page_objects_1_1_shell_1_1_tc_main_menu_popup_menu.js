var class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu =
[
    [ "About", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a1bcb4f0cbe70f26b900cbf004709eb5f", null ],
    [ "Exit", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a2686dbf8c122f8f836d532a9de534ee2", null ],
    [ "Help", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#ac6dc035ce1fb5474393fc7f36a254c6d", null ],
    [ "Refresh", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#a8289a174129893c72a803fee11604458", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#aaffc2c267917440b8024dbb2ecdd3142", null ],
    [ "Settings", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#aa97600ccd11065fb26340e6eb36b1d53", null ],
    [ "WelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html#aed6bbd3c2e12f358292635fcd0bb7e17", null ]
];