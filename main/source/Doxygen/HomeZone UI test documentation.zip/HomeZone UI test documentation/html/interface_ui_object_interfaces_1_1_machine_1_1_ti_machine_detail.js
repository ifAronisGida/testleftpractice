var interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail =
[
    [ "OpenMachineConfigurationBend", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#ac2c9c3bb7e4e787bd7ad52e3d2dc4d33", null ],
    [ "BendMachineType", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#aa7fa6a190abc4c5cd31e02e4ba753d54", null ],
    [ "CreateSubDirectory", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#a99f3d8d8d325fdab5ec2df88b41ff0fd", null ],
    [ "CutMachineType", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#acf999ec14ef898b051e8f6d18519d08b", null ],
    [ "LaserPower", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#ac44969bd09a654e38dca5a77adda9cda", null ],
    [ "MachineNumber", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#a582cff4670085ab66f12d10f254d6618", null ],
    [ "Name", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#a68e428c8570a6a841a9523a1d3328ae6", null ],
    [ "TransferDirectory", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html#adfca92d7c8cd7a41aed558105322890f", null ]
];