var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail =
[
    [ "LaserPower", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a69bbb71f03f19d7af93d4b2d1e63d524", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a77bbc02239228d57753805ea30cb12ff", null ],
    [ "BendMachineType", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#ac36e7f7ba1abca3000e6ed375dff86c2", null ],
    [ "CreateSubDirectory", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a26e6f9967903b716acbf96270bc1a9af", null ],
    [ "CutMachineType", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#ab3f9d4c853d6a44c2d5e0f0c310fe181", null ],
    [ "LaserPowerIndex", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a5403ab7ded0117002ec450ef7f126125", null ],
    [ "LaserPowerValue", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#ad685bb1fa167c3367a02d77a9a54167e", null ],
    [ "MachineNumber", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a4551155f7da79617810f06a5c7bdae95", null ],
    [ "Name", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a1098e3e82d50d38883842f9d1ed838ca", null ],
    [ "TransferDirectory", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a1998822eb27a12805d2a4a75a2246d8c", null ]
];