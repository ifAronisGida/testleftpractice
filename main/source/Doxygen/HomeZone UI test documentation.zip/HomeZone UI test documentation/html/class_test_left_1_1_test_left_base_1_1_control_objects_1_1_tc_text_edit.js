var class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_text_edit =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_text_edit.html#abf1c12529527233d225b7e7bf1a54239", null ],
    [ "Text", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_text_edit.html#a704310a775c6f5a898f4724360e9b8da", null ]
];