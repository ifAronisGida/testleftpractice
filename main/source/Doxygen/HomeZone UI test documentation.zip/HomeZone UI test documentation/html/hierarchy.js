var hierarchy =
[
    [ "ControlObject", null, [
      [ "TestLeft.TestLeftBase.ControlObjects.TcComboBox", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_combo_box.html", null ],
      [ "UiObjects.ControlObjects.TcDomainSelector", "class_ui_objects_1_1_control_objects_1_1_tc_domain_selector.html", null ],
      [ "UiObjects.ControlObjects.TcGroupPanel", "class_ui_objects_1_1_control_objects_1_1_tc_group_panel.html", null ],
      [ "UiObjects.ControlObjects.TcListView", "class_ui_objects_1_1_control_objects_1_1_tc_list_view.html", null ],
      [ "UiObjects.ControlObjects.TcOverlay", "class_ui_objects_1_1_control_objects_1_1_tc_overlay.html", null ],
      [ "UiObjects.Utilities.TcGenericControlObject", "class_ui_objects_1_1_utilities_1_1_tc_generic_control_object.html", [
        [ "UiObjects.ControlObjects.Composite.TcResultColumn", "class_ui_objects_1_1_control_objects_1_1_composite_1_1_tc_result_column.html", null ]
      ] ]
    ] ],
    [ "IAutoFactOptions", null, [
      [ "UiTests.Base.TcTestOptions", "class_ui_tests_1_1_base_1_1_tc_test_options.html", null ]
    ] ],
    [ "IChildOf", null, [
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutMainWindow", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_main_window.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStarFinishToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_star_finish_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStarHelpToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_star_help_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartEditToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_edit_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartSheetLayoutToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_sheet_layout_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartSimulationToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_simulation_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartTechnologyToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_technology_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcStartCutToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_start_cut_toolbar.html", null ],
      [ "UiObjects.PageObjects.Customer.TcCustomers", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html", null ],
      [ "UiObjects.PageObjects.Cut.TcCutMessageBox", "class_ui_objects_1_1_page_objects_1_1_cut_1_1_tc_cut_message_box.html", null ],
      [ "UiObjects.PageObjects.CutJob.TcCutJobContainedOrders", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_contained_orders.html", null ],
      [ "UiObjects.PageObjects.CutJob.TcCutJobDetail", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html", null ],
      [ "UiObjects.PageObjects.CutJob.TcCutJobs", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html", null ],
      [ "UiObjects.PageObjects.CutJob.TcCutJobSolution", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_solution.html", null ],
      [ "UiObjects.PageObjects.CutJob.TcCutJobToolbar", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html", null ],
      [ "UiObjects.PageObjects.Design.TcDesignMessageBox", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design_message_box.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcAboutDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcEntitySelectionDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_entity_selection_dialog.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcHelpDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_help_dialog.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcOpenFileDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_open_file_dialog.html", null ],
      [ "UiObjects.PageObjects.Machine.TcMachineDetail", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html", null ],
      [ "UiObjects.PageObjects.Machine.TcMachinePopupMenu", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html", null ],
      [ "UiObjects.PageObjects.Machine.TcMachines", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html", null ],
      [ "UiObjects.PageObjects.Machine.TcMachineToolbar", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html", null ],
      [ "UiObjects.PageObjects.Material.TcMaterialDetail", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html", null ],
      [ "UiObjects.PageObjects.Material.TcMaterials", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_materials.html", null ],
      [ "UiObjects.PageObjects.Material.TcMaterialToolbar", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html", null ],
      [ "UiObjects.PageObjects.Part.TcParts", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html", null ],
      [ "UiObjects.PageObjects.Part.TcPartSingleDetail", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html", null ],
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailBendSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html", null ],
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailCutSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html", null ],
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailDesign", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html", null ],
      [ "UiObjects.PageObjects.Part.TcPartToolbar", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_toolbar.html", null ],
      [ "UiObjects.PageObjects.PartOrder.TcPartOrderBaseInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html", null ],
      [ "UiObjects.PageObjects.PartOrder.TcPartOrderPartInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info.html", null ],
      [ "UiObjects.PageObjects.PartOrder.TcPartOrders", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_orders.html", null ],
      [ "UiObjects.PageObjects.PartOrder.TcPartOrderToolbar", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html", null ],
      [ "UiObjects.PageObjects.Settings.TcBendSettings", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_bend_settings.html", null ],
      [ "UiObjects.PageObjects.Settings.TcSettingsDialog", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDetailContent", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_detail_content.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomains", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomainsAndFilters", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains_and_filters.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomainsMore", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains_more.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainMenuPopupMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainTabControl", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainWindow", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_window.html", null ],
      [ "UiObjects.PageObjects.Shell.TcToolbars", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_toolbars.html", null ],
      [ "UiObjects.PageObjects.Shell.TcWelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html", null ]
    ] ],
    [ "PageObject", null, [
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutMainWindow", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_main_window.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStarFinishToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_star_finish_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStarHelpToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_star_help_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartEditToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_edit_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartSheetLayoutToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_sheet_layout_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartSimulationToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_simulation_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcCutStartTechnologyToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_start_technology_toolbar.html", null ],
      [ "TestLeft.TestLeftBase.PageObjects.Cut.TcStartCutToolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_start_cut_toolbar.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcAboutDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcHelpDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_help_dialog.html", null ],
      [ "UiObjects.PageObjects.Machine.TcMachinePopupMenu", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html", null ],
      [ "UiObjects.PageObjects.Material.TcMaterialDetail", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDetailContent", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_detail_content.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomains", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomainsAndFilters", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains_and_filters.html", null ],
      [ "UiObjects.PageObjects.Shell.TcDomainsMore", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_domains_more.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainMenuPopupMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu_popup_menu.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainTabControl", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html", null ],
      [ "UiObjects.PageObjects.Shell.TcMainWindow", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_window.html", null ],
      [ "UiObjects.PageObjects.Shell.TcToolbars", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_toolbars.html", null ],
      [ "UiObjects.PageObjects.TcPageObjectBase", "class_ui_objects_1_1_page_objects_1_1_tc_page_object_base.html", [
        [ "UiObjects.PageObjects.Customer.TcCustomers", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html", null ],
        [ "UiObjects.PageObjects.CutJob.TcCutJobContainedOrders", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_contained_orders.html", null ],
        [ "UiObjects.PageObjects.CutJob.TcCutJobDetail", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html", null ],
        [ "UiObjects.PageObjects.CutJob.TcCutJobSolution", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_solution.html", null ],
        [ "UiObjects.PageObjects.CutJob.TcCutJobToolbar", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html", null ],
        [ "UiObjects.PageObjects.Dialogs.TcEntitySelectionDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_entity_selection_dialog.html", null ],
        [ "UiObjects.PageObjects.Machine.TcMachineDetail", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html", null ],
        [ "UiObjects.PageObjects.Machine.TcMachineToolbar", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html", null ],
        [ "UiObjects.PageObjects.Material.TcMaterialToolbar", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html", null ],
        [ "UiObjects.PageObjects.Part.TcPartSingleDetail", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html", null ],
        [ "UiObjects.PageObjects.Part.TcPartSingleDetailBendSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html", null ],
        [ "UiObjects.PageObjects.Part.TcPartSingleDetailCutSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html", null ],
        [ "UiObjects.PageObjects.Part.TcPartSingleDetailDesign", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html", null ],
        [ "UiObjects.PageObjects.Part.TcPartToolbar", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_toolbar.html", null ],
        [ "UiObjects.PageObjects.PartOrder.TcPartOrderPartInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info.html", null ],
        [ "UiObjects.PageObjects.PartOrder.TcPartOrderToolbar", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html", null ],
        [ "UiObjects.PageObjects.Settings.TcBendSettings", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_bend_settings.html", null ],
        [ "UiObjects.PageObjects.Settings.TcSettingsDialog", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html", null ],
        [ "UiObjects.PageObjects.Shell.TcWelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html", null ],
        [ "UiObjects.PageObjects.TcExpandablePageObject", "class_ui_objects_1_1_page_objects_1_1_tc_expandable_page_object.html", [
          [ "UiObjects.PageObjects.PartOrder.TcPartOrderBaseInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html", null ]
        ] ]
      ] ]
    ] ],
    [ "ProcessObject", null, [
      [ "UiObjects.TcHomeZoneApp", "class_ui_objects_1_1_tc_home_zone_app.html", null ]
    ] ],
    [ "RepeaterObject", null, [
      [ "UiObjects.PageObjects.Cut.TcCutMessageBox", "class_ui_objects_1_1_page_objects_1_1_cut_1_1_tc_cut_message_box.html", null ],
      [ "UiObjects.PageObjects.Design.TcDesignMessageBox", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design_message_box.html", null ],
      [ "UiObjects.PageObjects.Dialogs.TcOpenFileDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_open_file_dialog.html", null ],
      [ "UiObjects.PageObjects.TcDomain< TToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", null ],
      [ "UiObjects.PageObjects.TcRepeaterObjectBase", "class_ui_objects_1_1_page_objects_1_1_tc_repeater_object_base.html", null ]
    ] ],
    [ "UiTests.Base.TcBaseTestClass", "class_ui_tests_1_1_base_1_1_tc_base_test_class.html", [
      [ "SmokeTests.Smoke.TcMiniSmokeTest", "class_smoke_tests_1_1_smoke_1_1_tc_mini_smoke_test.html", null ],
      [ "UiTests.Customer.TcCustomerTest", "class_ui_tests_1_1_customer_1_1_tc_customer_test.html", null ],
      [ "UiTests.Cut.TcCutTest", "class_ui_tests_1_1_cut_1_1_tc_cut_test.html", null ],
      [ "UiTests.CutJob.TcCutJobTest", "class_ui_tests_1_1_cut_job_1_1_tc_cut_job_test.html", null ],
      [ "UiTests.Design.TcDesignTest", "class_ui_tests_1_1_design_1_1_tc_design_test.html", null ],
      [ "UiTests.Flux.TcFluxTest", "class_ui_tests_1_1_flux_1_1_tc_flux_test.html", null ],
      [ "UiTests.Machine.TcWorkplaceTest", "class_ui_tests_1_1_machine_1_1_tc_workplace_test.html", null ],
      [ "UiTests.Material.TcMaterialTest", "class_ui_tests_1_1_material_1_1_tc_material_test.html", null ],
      [ "UiTests.NestingTemplate.TcNestingTemplateTest", "class_ui_tests_1_1_nesting_template_1_1_tc_nesting_template_test.html", null ],
      [ "UiTests.Part.TcPartTest", "class_ui_tests_1_1_part_1_1_tc_part_test.html", null ],
      [ "UiTests.PartOrder.TcPartOrderTest", "class_ui_tests_1_1_part_order_1_1_tc_part_order_test.html", null ],
      [ "UiTests.Settings.TcBendSettingsTest", "class_ui_tests_1_1_settings_1_1_tc_bend_settings_test.html", null ],
      [ "UiTests.Settings.TcBendToolListsTest", "class_ui_tests_1_1_settings_1_1_tc_bend_tool_lists_test.html", null ],
      [ "UiTests.Settings.TcSettingsDialogTest", "class_ui_tests_1_1_settings_1_1_tc_settings_dialog_test.html", null ],
      [ "UiTests.Shell.TcMainMenuTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html", null ],
      [ "UiTests.Shell.TcShellTest", "class_ui_tests_1_1_shell_1_1_tc_shell_test.html", null ],
      [ "UiTests.Shell.TcWelcomeScreenTest", "class_ui_tests_1_1_shell_1_1_tc_welcome_screen_test.html", null ],
      [ "UiTests.Utilities.TcSmokeHelpers", "class_ui_tests_1_1_utilities_1_1_tc_smoke_helpers.html", null ],
      [ "UiTests.Utilities.TcSmokeTestsPart", "class_ui_tests_1_1_utilities_1_1_tc_smoke_tests_part.html", null ]
    ] ],
    [ "UiObjects.PageObjects.Customer.TcCustomerRow", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html", null ],
    [ "UiObjects.PageObjects.TcDomain< TiCutJobToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", [
      [ "UiObjects.PageObjects.CutJob.TcCutJobs", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html", null ]
    ] ],
    [ "UiObjects.PageObjects.TcDomain< TiMachineToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", [
      [ "UiObjects.PageObjects.Machine.TcMachines", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html", null ]
    ] ],
    [ "UiObjects.PageObjects.TcDomain< TiMaterialToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", [
      [ "UiObjects.PageObjects.Material.TcMaterials", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_materials.html", null ]
    ] ],
    [ "UiObjects.PageObjects.TcDomain< TiNestingTemplateToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", null ],
    [ "UiObjects.PageObjects.TcDomain< TiPartOrderToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", [
      [ "UiObjects.PageObjects.PartOrder.TcPartOrders", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_orders.html", null ]
    ] ],
    [ "UiObjects.PageObjects.TcDomain< TiPartToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", [
      [ "UiObjects.PageObjects.Part.TcParts", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html", null ]
    ] ],
    [ "UiObjects.PageObjects.Flux.TcFluxConfigureMachine", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux_configure_machine.html", null ],
    [ "UiObjects.PageObjects.Flux.TcLandingPages", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_landing_pages.html", null ],
    [ "UiObjects.ControlObjects.Grid.TcTableView< TRow, TInternalRow >", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_table_view.html", null ],
    [ "UiObjects.ControlObjects.Grid.TcTableView< TRow, TcOptimizedTableRow >", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_table_view.html", [
      [ "UiObjects.ControlObjects.Grid.TcOptimizedTableView< TRow >", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_optimized_table_view.html", null ]
    ] ],
    [ "UiObjects.ControlObjects.Grid.TcTableView< TRow, TcTableRow >", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_table_view.html", [
      [ "UiObjects.ControlObjects.Grid.TcRegularTableView< TRow >", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_regular_table_view.html", null ]
    ] ],
    [ "UiObjects.TestSettings.TcTestSettings", "class_ui_objects_1_1_test_settings_1_1_tc_test_settings.html", null ],
    [ "UiObjectInterfaces.TiApp", "interface_ui_object_interfaces_1_1_ti_app.html", [
      [ "UiObjectInterfaces.Cut.TiCut", "interface_ui_object_interfaces_1_1_cut_1_1_ti_cut.html", [
        [ "UiObjects.PageObjects.Cut.TcCut", "class_ui_objects_1_1_page_objects_1_1_cut_1_1_tc_cut.html", null ]
      ] ],
      [ "UiObjectInterfaces.Design.TiDesign", "interface_ui_object_interfaces_1_1_design_1_1_ti_design.html", [
        [ "UiObjects.PageObjects.Design.TcDesign", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design.html", null ]
      ] ],
      [ "UiObjectInterfaces.Flux.TiFlux", "interface_ui_object_interfaces_1_1_flux_1_1_ti_flux.html", [
        [ "UiObjects.PageObjects.Flux.TcFlux", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html", null ]
      ] ],
      [ "UiObjects.TcApp", "class_ui_objects_1_1_tc_app.html", [
        [ "UiObjects.PageObjects.Cut.TcCut", "class_ui_objects_1_1_page_objects_1_1_cut_1_1_tc_cut.html", null ],
        [ "UiObjects.PageObjects.Design.TcDesign", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design.html", null ],
        [ "UiObjects.PageObjects.Flux.TcFlux", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux.html", null ]
      ] ]
    ] ],
    [ "UiObjectInterfaces.Controls.TiControl", "interface_ui_object_interfaces_1_1_controls_1_1_ti_control.html", [
      [ "UiObjectInterfaces.Controls.TiButton", "interface_ui_object_interfaces_1_1_controls_1_1_ti_button.html", null ],
      [ "UiObjectInterfaces.Controls.TiValueControl< T >", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html", null ]
    ] ],
    [ "UiObjectInterfaces.Customer.TiCustomers", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html", [
      [ "UiObjects.PageObjects.Customer.TcCustomers", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiCutJobBaseInfo", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_base_info.html", [
      [ "UiObjects.PageObjects.CutJob.TcCutJobDetail", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_detail.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiCutJobContainedOrders", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html", [
      [ "UiObjects.PageObjects.CutJob.TcCutJobContainedOrders", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_contained_orders.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiCutJobOrderRow", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_order_row.html", [
      [ "UiObjects.PageObjects.CutJob.TcCutJobOrderRow", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_order_row.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiCutJobSheetProgram", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_sheet_program.html", [
      [ "UiObjects.PageObjects.CutJob.TcCutJobSolution", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_solution.html", null ]
    ] ],
    [ "UiObjectInterfaces.Dialogs.TiEntitySelectionDialog", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_entity_selection_dialog.html", [
      [ "UiObjects.PageObjects.Dialogs.TcEntitySelectionDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_entity_selection_dialog.html", null ]
    ] ],
    [ "UiObjectInterfaces.TiHomeZoneApp", "interface_ui_object_interfaces_1_1_ti_home_zone_app.html", [
      [ "UiObjects.TcHomeZoneApp", "class_ui_objects_1_1_tc_home_zone_app.html", null ]
    ] ],
    [ "UiObjectInterfaces.Machine.TiMachineDetail", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_detail.html", [
      [ "UiObjects.PageObjects.Machine.TcMachineDetail", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html", null ]
    ] ],
    [ "UiObjectInterfaces.Shell.TiMainMenu", "interface_ui_object_interfaces_1_1_shell_1_1_ti_main_menu.html", [
      [ "UiObjects.PageObjects.Shell.TcMainMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html", null ]
    ] ],
    [ "UiObjectInterfaces.Shell.TiMainTabControl", "interface_ui_object_interfaces_1_1_shell_1_1_ti_main_tab_control.html", [
      [ "UiObjects.PageObjects.Shell.TcMainTabControl", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html", null ]
    ] ],
    [ "UiObjectInterfaces.Material.TiMaterialDetail", "interface_ui_object_interfaces_1_1_material_1_1_ti_material_detail.html", [
      [ "UiObjects.PageObjects.Material.TcMaterialDetail", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_detail.html", null ]
    ] ],
    [ "UiObjectInterfaces.Dialogs.TiMessageBox", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_message_box.html", null ],
    [ "UiObjectInterfaces.NestingTemplate.TiNestingTemplateBaseInfo", "interface_ui_object_interfaces_1_1_nesting_template_1_1_ti_nesting_template_base_info.html", null ],
    [ "UiObjectInterfaces.NestingTemplate.TiNestingTemplatePart", "interface_ui_object_interfaces_1_1_nesting_template_1_1_ti_nesting_template_part.html", null ],
    [ "UiObjectInterfaces.NestingTemplate.TiNestingTemplatePartList", "interface_ui_object_interfaces_1_1_nesting_template_1_1_ti_nesting_template_part_list.html", null ],
    [ "UiObjectInterfaces.Dialogs.TiOpenFileDialog", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_open_file_dialog.html", [
      [ "UiObjects.PageObjects.Dialogs.TcOpenFileDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_open_file_dialog.html", null ]
    ] ],
    [ "UiObjectInterfaces.Dialogs.TiPartComputeAllConfirmation", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_part_compute_all_confirmation.html", null ],
    [ "UiObjectInterfaces.PartOrder.TiPartOrderBaseInfo", "interface_ui_object_interfaces_1_1_part_order_1_1_ti_part_order_base_info.html", [
      [ "UiObjects.PageObjects.PartOrder.TcPartOrderBaseInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html", null ]
    ] ],
    [ "UiObjectInterfaces.PartOrder.TiPartOrderPartInfo", "interface_ui_object_interfaces_1_1_part_order_1_1_ti_part_order_part_info.html", [
      [ "UiObjects.PageObjects.PartOrder.TcPartOrderPartInfo", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_part_info.html", null ]
    ] ],
    [ "UiObjectInterfaces.Part.TiPartSingleDetail", "interface_ui_object_interfaces_1_1_part_1_1_ti_part_single_detail.html", [
      [ "UiObjects.PageObjects.Part.TcPartSingleDetail", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html", null ]
    ] ],
    [ "UiObjectInterfaces.Part.TiPartSingleDetailBendSolutions", "interface_ui_object_interfaces_1_1_part_1_1_ti_part_single_detail_bend_solutions.html", [
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailBendSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html", null ]
    ] ],
    [ "UiObjectInterfaces.Part.TiPartSingleDetailCutSolutions", "interface_ui_object_interfaces_1_1_part_1_1_ti_part_single_detail_cut_solutions.html", [
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailCutSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html", null ]
    ] ],
    [ "UiObjectInterfaces.Part.TiPartSingleDetailDesign", "interface_ui_object_interfaces_1_1_part_1_1_ti_part_single_detail_design.html", [
      [ "UiObjects.PageObjects.Part.TcPartSingleDetailDesign", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiRawSheet", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet.html", [
      [ "UiObjects.PageObjects.CutJob.TcRawSheet", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_raw_sheet.html", null ]
    ] ],
    [ "UiObjectInterfaces.CutJob.TiRawSheetList", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_raw_sheet_list.html", [
      [ "UiObjects.PageObjects.CutJob.TcRawSheetList", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_raw_sheet_list.html", null ]
    ] ],
    [ "UiObjectInterfaces.Common.TiResultColumn", "interface_ui_object_interfaces_1_1_common_1_1_ti_result_column.html", [
      [ "UiObjects.ControlObjects.Composite.TcResultColumn", "class_ui_objects_1_1_control_objects_1_1_composite_1_1_tc_result_column.html", null ]
    ] ],
    [ "UiObjectInterfaces.Cut.TiTTSelectionDialog", "interface_ui_object_interfaces_1_1_cut_1_1_ti_t_t_selection_dialog.html", [
      [ "UiObjects.PageObjects.Cut.TcTTSelectionDialog", "class_ui_objects_1_1_page_objects_1_1_cut_1_1_tc_t_t_selection_dialog.html", null ]
    ] ],
    [ "UiObjectInterfaces.Controls.TiValueControl< bool >", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html", null ],
    [ "UiObjectInterfaces.Controls.TiValueControl< DateTime?>", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html", null ],
    [ "UiObjectInterfaces.Controls.TiValueControl< int >", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html", null ],
    [ "UiObjectInterfaces.Controls.TiValueControl< string >", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html", null ],
    [ "UiObjectInterfaces.Common.TiVisibility", "interface_ui_object_interfaces_1_1_common_1_1_ti_visibility.html", [
      [ "UiObjectInterfaces.Common.TiDomain", "interface_ui_object_interfaces_1_1_common_1_1_ti_domain.html", [
        [ "UiObjectInterfaces.CutJob.TiCutJobs", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_jobs.html", [
          [ "UiObjects.PageObjects.CutJob.TcCutJobs", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html", null ]
        ] ],
        [ "UiObjectInterfaces.Machine.TiMachines", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html", [
          [ "UiObjects.PageObjects.Machine.TcMachines", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html", null ]
        ] ],
        [ "UiObjectInterfaces.Material.TiMaterials", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html", [
          [ "UiObjects.PageObjects.Material.TcMaterials", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_materials.html", null ]
        ] ],
        [ "UiObjectInterfaces.NestingTemplate.TiNestingTemplates", "interface_ui_object_interfaces_1_1_nesting_template_1_1_ti_nesting_templates.html", null ],
        [ "UiObjectInterfaces.Part.TiParts", "interface_ui_object_interfaces_1_1_part_1_1_ti_parts.html", [
          [ "UiObjects.PageObjects.Part.TcParts", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html", null ]
        ] ],
        [ "UiObjectInterfaces.PartOrder.TiPartOrders", "interface_ui_object_interfaces_1_1_part_order_1_1_ti_part_orders.html", [
          [ "UiObjects.PageObjects.PartOrder.TcPartOrders", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_orders.html", null ]
        ] ],
        [ "UiObjects.PageObjects.TcDomain< TToolbar >", "class_ui_objects_1_1_page_objects_1_1_tc_domain.html", null ]
      ] ],
      [ "UiObjectInterfaces.CutJob.TiCutJobToolbar", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html", [
        [ "UiObjects.PageObjects.CutJob.TcCutJobToolbar", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html", null ]
      ] ],
      [ "UiObjectInterfaces.Dialogs.TiAboutDialog", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_about_dialog.html", [
        [ "UiObjects.PageObjects.Dialogs.TcAboutDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html", null ]
      ] ],
      [ "UiObjectInterfaces.Dialogs.TiHelpDialog", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_help_dialog.html", [
        [ "UiObjects.PageObjects.Dialogs.TcHelpDialog", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_help_dialog.html", null ]
      ] ],
      [ "UiObjectInterfaces.Machine.TiMachineToolbar", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html", [
        [ "UiObjects.PageObjects.Machine.TcMachineToolbar", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html", null ]
      ] ],
      [ "UiObjectInterfaces.Material.TiMaterialToolbar", "interface_ui_object_interfaces_1_1_material_1_1_ti_material_toolbar.html", [
        [ "UiObjects.PageObjects.Material.TcMaterialToolbar", "class_ui_objects_1_1_page_objects_1_1_material_1_1_tc_material_toolbar.html", null ]
      ] ],
      [ "UiObjectInterfaces.NestingTemplate.TiNestingTemplateToolbar", "interface_ui_object_interfaces_1_1_nesting_template_1_1_ti_nesting_template_toolbar.html", null ],
      [ "UiObjectInterfaces.Part.TiPartToolbar", "interface_ui_object_interfaces_1_1_part_1_1_ti_part_toolbar.html", [
        [ "UiObjects.PageObjects.Part.TcPartToolbar", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_toolbar.html", null ]
      ] ],
      [ "UiObjectInterfaces.PartOrder.TiPartOrderToolbar", "interface_ui_object_interfaces_1_1_part_order_1_1_ti_part_order_toolbar.html", [
        [ "UiObjects.PageObjects.PartOrder.TcPartOrderToolbar", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html", null ]
      ] ],
      [ "UiObjectInterfaces.Settings.TiBendSettings", "interface_ui_object_interfaces_1_1_settings_1_1_ti_bend_settings.html", [
        [ "UiObjects.PageObjects.Settings.TcBendSettings", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_bend_settings.html", null ]
      ] ],
      [ "UiObjectInterfaces.Settings.TiSettingsDialog", "interface_ui_object_interfaces_1_1_settings_1_1_ti_settings_dialog.html", [
        [ "UiObjects.PageObjects.Settings.TcSettingsDialog", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html", null ]
      ] ],
      [ "UiObjectInterfaces.Shell.TiWelcomeScreen", "interface_ui_object_interfaces_1_1_shell_1_1_ti_welcome_screen.html", [
        [ "UiObjects.PageObjects.Shell.TcWelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_welcome_screen.html", null ]
      ] ]
    ] ],
    [ "ViewControlObject", null, [
      [ "UiObjects.ControlObjects.Grid.TcOptimizedTableRow", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_optimized_table_row.html", null ],
      [ "UiObjects.ControlObjects.Grid.TcTableRow", "class_ui_objects_1_1_control_objects_1_1_grid_1_1_tc_table_row.html", null ],
      [ "UiObjects.ControlObjects.TcGridControl", "class_ui_objects_1_1_control_objects_1_1_tc_grid_control.html", null ]
    ] ]
];