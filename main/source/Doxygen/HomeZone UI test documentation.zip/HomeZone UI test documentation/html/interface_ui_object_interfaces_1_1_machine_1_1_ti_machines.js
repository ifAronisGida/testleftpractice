var interface_ui_object_interfaces_1_1_machine_1_1_ti_machines =
[
    [ "DeleteMachine", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a89cc5225d59998c4773df5970cdcc5cb", null ],
    [ "NewBendMachine", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a8fcdd6dd0ceb828c97a918a889e62fb9", null ],
    [ "NewCutMachine", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#ab2d513ec460cfcd95d7d660867535126", null ],
    [ "WaitForDetailOverlayAppear", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a2fb6b750a503222d1916762e76f1f525", null ],
    [ "WaitForDetailOverlayDisappear", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a8d5d372c3c99beb40901804bbd3a5139", null ],
    [ "Detail", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a78a5f7cd5c6948db1f4d8152747d6b2b", null ],
    [ "Toolbar", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machines.html#a3edfbf9fbd18e7e09023f222cb75257a", null ]
];