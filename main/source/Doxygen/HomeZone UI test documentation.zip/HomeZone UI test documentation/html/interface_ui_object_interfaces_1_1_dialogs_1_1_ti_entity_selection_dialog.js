var interface_ui_object_interfaces_1_1_dialogs_1_1_ti_entity_selection_dialog =
[
    [ "Cancel", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_entity_selection_dialog.html#ae5dd6bd524c363dfb261f0b2ef904bab", null ],
    [ "Ok", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_entity_selection_dialog.html#a060a7f0e337c23f900bb2d61e8784fb2", null ],
    [ "SelectClose", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_entity_selection_dialog.html#a060b9328bff9b1b9525b818119faa3ac", null ]
];