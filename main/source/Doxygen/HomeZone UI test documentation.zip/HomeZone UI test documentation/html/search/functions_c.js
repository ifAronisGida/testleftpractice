var searchData=
[
  ['refreshmasterdata',['RefreshMasterData',['../class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#ae52eaf75c9b3c2d0bc372359b4a26b34',1,'TestLeft::TestLeftBase::PageObjects::Shell::TcMainMenu']]],
  ['refreshmasterdatatest',['RefreshMasterDataTest',['../class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_main_menu_test.html#afc91b83be714001992d72f954e2c96a6',1,'TestLeft::UI_Tests::Shell::TcMainMenuTest']]]
];
