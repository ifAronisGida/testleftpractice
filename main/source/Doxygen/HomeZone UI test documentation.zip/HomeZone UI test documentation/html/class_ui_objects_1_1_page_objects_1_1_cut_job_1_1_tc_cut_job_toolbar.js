var class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar =
[
    [ "Delete", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#a57655fd99542ecbf31210cd4a7386551", null ],
    [ "New", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#a9ddc7f50f1a287491b9172f29e4acb3f", null ],
    [ "Revert", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#aebfca030025b919c3235683a31a0723a", null ],
    [ "Save", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#aff7d0eed9dd2c49197a0ccda6ff792da", null ],
    [ "CanDelete", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#a5c8f2aad3f8149168c76d09c39d682c2", null ],
    [ "CanRevert", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#a9ffc1f8012449143d588affb1605f2c1", null ],
    [ "CanSave", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#aa67ab593eb9bc39c6267f55195c9eeac", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_cut_job_1_1_tc_cut_job_toolbar.html#a832d544157a5f8ca2398decb2305322c", null ]
];