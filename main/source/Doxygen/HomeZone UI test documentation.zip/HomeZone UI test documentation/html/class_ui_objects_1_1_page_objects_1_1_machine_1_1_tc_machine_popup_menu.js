var class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu =
[
    [ "NewBendMachineButton", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#a44f2b91c937fc1217e0176feac038b3d", null ],
    [ "NewCutMachineButton", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#a58125f145f760da3d022cf3c0879a2e8", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#a72df2f8ed139a6c90af33c22640f9d5b", null ]
];