var interface_ui_object_interfaces_1_1_controls_1_1_ti_control =
[
    [ "Enabled", "interface_ui_object_interfaces_1_1_controls_1_1_ti_control.html#ad9076bcf36b2ac575fa83b6870993c0b", null ],
    [ "Visible", "interface_ui_object_interfaces_1_1_controls_1_1_ti_control.html#a04a8e3ef059d85a45b7a47c1c6730192", null ]
];