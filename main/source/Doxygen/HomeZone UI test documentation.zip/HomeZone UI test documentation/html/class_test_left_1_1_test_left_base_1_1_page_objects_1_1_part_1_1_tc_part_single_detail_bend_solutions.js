var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions =
[
    [ "New", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a05b22e82d18cf049f82f979cefa0393e", null ],
    [ "OpenBendSolution", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#acbdc0b65a4b1bea01d5004cc805cd240", null ],
    [ "Count", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#ac396a6c5f526429d44b9df2c4e0788bf", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a9035d884f4ed3c479653d84742d93822", null ]
];