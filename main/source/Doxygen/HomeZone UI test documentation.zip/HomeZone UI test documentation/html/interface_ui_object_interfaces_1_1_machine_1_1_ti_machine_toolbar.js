var interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar =
[
    [ "Delete", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#abfec06a3d5441ed559fc622f7f757a13", null ],
    [ "NewBendMachine", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#abad8e1d1b4da01d3a5891d793eb53b21", null ],
    [ "NewCutMachine", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#a1729b64cea09b5feb478c2b5d927c9a4", null ],
    [ "Save", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#a91bc4ee7b81eabcdbcb921a3504414b3", null ],
    [ "CanDelete", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#a0f6ce6edaea0e6ba839827249ffac6bd", null ],
    [ "CanRevert", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#a094f3201b85c695ffbb897b5fe62bb4f", null ],
    [ "CanSave", "interface_ui_object_interfaces_1_1_machine_1_1_ti_machine_toolbar.html#aefe165372dc7b5eb8eed5d41bd090ea4", null ]
];