var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_base_info =
[
    [ "FinishDate", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_base_info.html#a6a4f5d1e98b10362c5461ae970ab4ba5", null ],
    [ "Id", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_base_info.html#a06bb83617a8a4eb297987b1869acc33d", null ],
    [ "RawMaterial", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_base_info.html#a1576870ab5740ddc24a0c6bcf06c67e3", null ]
];