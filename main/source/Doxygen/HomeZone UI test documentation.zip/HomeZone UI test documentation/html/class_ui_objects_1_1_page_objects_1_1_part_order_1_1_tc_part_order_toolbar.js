var class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar =
[
    [ "Delete", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#a7d60c8ae40be327f0e6b0a5594ba3ea8", null ],
    [ "New", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#ad821bcffeed6031b97d3849e7b5c9dbf", null ],
    [ "Save", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#a99b8411a3137edec0d61dbbe4d2757ac", null ],
    [ "CanDelete", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#a61ba6de6a9ad137919de0cda0e12beda", null ],
    [ "CanSave", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#afad2b50f055a59ed10e7a4d072765c69", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_toolbar.html#a871292fc21cb75fa8dcc705ee502b850", null ]
];