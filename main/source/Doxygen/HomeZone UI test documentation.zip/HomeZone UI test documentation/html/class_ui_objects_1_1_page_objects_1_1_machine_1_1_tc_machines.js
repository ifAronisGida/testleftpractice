var class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines =
[
    [ "DeleteMachine", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a118572e5463ebe43d2f0cf06eeff5231", null ],
    [ "DoGoto", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a8825acd6ddfff9a12dc4a691d0f9f1e7", null ],
    [ "NewBendMachine", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a7fb9c444ff413ec80bde7c5a06425a03", null ],
    [ "NewCutMachine", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a1df6efec8777f467e991e3162f330a56", null ],
    [ "WaitForDetailOverlayAppear", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a9969ed4ddb8c530191996489c21e073d", null ],
    [ "WaitForDetailOverlayDisappear", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ad1385f5eee2c0f89acffc05be6bf0c8c", null ],
    [ "Detail", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a7bfb076ac0783e1ecd30ea56f66a5983", null ],
    [ "Popup", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ac469d0c5902d4eedde127031982adcd5", null ],
    [ "Toolbar", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machines.html#acfb701d28d21425bab83da39f78f7d21", null ]
];