var class_ui_objects_1_1_control_objects_1_1_tc_group_panel =
[
    [ "SearchPattern", "class_ui_objects_1_1_control_objects_1_1_tc_group_panel.html#a21d9ecdedf8172f164b78c020540ef4e", null ],
    [ "IsMoreExpanded", "class_ui_objects_1_1_control_objects_1_1_tc_group_panel.html#a9396142e832749db0ad7c81d46f398fb", null ]
];