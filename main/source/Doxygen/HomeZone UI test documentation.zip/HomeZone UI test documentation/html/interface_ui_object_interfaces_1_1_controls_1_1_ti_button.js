var interface_ui_object_interfaces_1_1_controls_1_1_ti_button =
[
    [ "Click", "interface_ui_object_interfaces_1_1_controls_1_1_ti_button.html#a80e2fb6853e972ee51dbf6bcb2eb7fa4", null ],
    [ "Label", "interface_ui_object_interfaces_1_1_controls_1_1_ti_button.html#a9c51b75d8c68fc9ff3544c4a0d623245", null ]
];