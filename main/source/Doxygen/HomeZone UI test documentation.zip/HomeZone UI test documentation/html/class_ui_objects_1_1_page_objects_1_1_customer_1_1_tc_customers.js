var class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers =
[
    [ "TcCustomers", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a8dca46b93f64190bf8cc2a36dfa62704", null ],
    [ "Apply", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a69deb466347cc72f1eff701e171e2160", null ],
    [ "Cancel", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a6b456dbb93fe7cad7b2c5f0a36352f43", null ],
    [ "Count", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a0cb20940ec83dc36b0c641547298bb4a", null ],
    [ "DeleteCustomer", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a2b44dd19bbe0cbc8ebf87aad10b31cb4", null ],
    [ "DeleteCustomersWithNameContaining", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a9baa20c61df85ee7cbfc2b8cfc161797", null ],
    [ "DeleteSelectedCustomers", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a815823a307fcab7a97216b0859176b43", null ],
    [ "Goto", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ac7fe12e73c33ffc699554171c434d914", null ],
    [ "NewCustomer", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ad8a4e4546c91f1128838f68d14d75dda", null ],
    [ "Select", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#abab802da3aa6bac8408d086d73ef39d1", null ],
    [ "SelectCustomer", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a20a8c4262a959a4e6d26bcdfc15b488c", null ],
    [ "SelectedCustomersCount", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#afe8e42aebe3340d3a58f5319d0c3830e", null ],
    [ "SelectOnlyCustomersWithNameContaining", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a765ecdd610aa112c35a94522a1e96561", null ],
    [ "City", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a61b603e29f51c165632ff70bb149e6d1", null ],
    [ "Comment", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ab9983b633e9314da3fac8e7fc83720f0", null ],
    [ "Country", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ab8670661b06565c7419007a0be8f352d", null ],
    [ "Id", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#abd4fd88348a8ede1c2b5a7f14c901c16", null ],
    [ "Name", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a3e938a96c7c7d90da1af67a2c067843c", null ],
    [ "PostalCode", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a67724bfd9ab310ec055016862d2b1330", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ac75ebcd089c7280d39ed511c849e942a", null ],
    [ "Street", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a70061c51fc5062d669e00fde3ebc8f3d", null ]
];