var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar =
[
    [ "Delete", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a2044db325319eb41428f97a55409ccee", null ],
    [ "New", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a64c67bdd3f69bdd9e9955cb58e640ee6", null ],
    [ "Revert", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a71cdf99950e19450948998d714183dd4", null ],
    [ "Save", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a1a7ee7e32dfa1b694a0cfc60ac99c6c6", null ],
    [ "CanDelete", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a6fed51019dec256e58131917f795e13a", null ],
    [ "CanRevert", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a265ca2824e5e0f0a373c3827622d8e11", null ],
    [ "CanSave", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_toolbar.html#a1c45973ca956ad14fe50fcdb1db3c0b6", null ]
];