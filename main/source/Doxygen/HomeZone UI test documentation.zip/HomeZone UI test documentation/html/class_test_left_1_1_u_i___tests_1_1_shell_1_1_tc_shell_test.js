var class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_shell_test =
[
    [ "Add10Tabs", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_shell_test.html#a553b844bd0c644e4b0a4648b70ef89a4", null ],
    [ "Add10TabsWithPartSelected", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_shell_test.html#a1b7517c895e89298f782947d8428ba4b", null ],
    [ "AddTab", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_shell_test.html#a19a99afe07a30af8ae320812c54fcbc3", null ],
    [ "CloseAllAdditionalTabs", "class_test_left_1_1_u_i___tests_1_1_shell_1_1_tc_shell_test.html#ae322d5d5c036e7c66a8223413b44d3ad", null ]
];