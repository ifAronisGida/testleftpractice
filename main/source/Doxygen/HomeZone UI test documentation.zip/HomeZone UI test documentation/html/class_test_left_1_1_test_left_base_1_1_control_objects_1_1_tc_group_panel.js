var class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_group_panel =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_group_panel.html#a3becb6040f6a3e88894e12f13b67effe", null ],
    [ "IsMoreExpanded", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_group_panel.html#a9d4e8337d81afebf01a81a92b927f744", null ]
];