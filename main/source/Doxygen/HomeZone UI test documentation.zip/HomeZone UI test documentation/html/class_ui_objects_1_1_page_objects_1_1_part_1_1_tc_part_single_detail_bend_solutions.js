var class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions =
[
    [ "BoostSolution", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a74b3dd9f5d5fda77b96a4ca6b3f927c3", null ],
    [ "IsManuallyChanged", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#ab0fce2be99d9c845ea14f33c3bf12551", null ],
    [ "NcButtonVisible", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#ac9ed6ae70820e319d81cbb18c697accb", null ],
    [ "New", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a3c70597d80cd2852863ab0f2a1d10887", null ],
    [ "OpenBendSolution", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#aae6f76b879c8e61770c249be94becf6d", null ],
    [ "OpenSolutionDetail", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a7e05be9ee4c61eadc40777d0533b76ba", null ],
    [ "ReleaseButtonVisible", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a91ffea6fdcfed8d3c3cba3a7f6a8b6a2", null ],
    [ "SetupPlanButtonVisible", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#af076a3c243b29b481a842dfa2a946495", null ],
    [ "ToggleReleaseButton", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#ab35c96cfbedc2c9963a1a5c4859a3fef", null ],
    [ "Count", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#ad2469d45b1f6b251c8a1e498995f67b0", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_bend_solutions.html#a418f3b277319ad4a35b024eff1582529", null ]
];