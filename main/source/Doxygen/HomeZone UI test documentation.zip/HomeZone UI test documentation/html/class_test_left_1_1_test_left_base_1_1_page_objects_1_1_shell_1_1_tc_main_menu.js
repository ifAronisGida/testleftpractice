var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu =
[
    [ "TcMainMenu", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#ae0cfcb6d8c16db38fdc58e801f6062da", null ],
    [ "CloseApplication", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#af9daa7cf71676a60fcc0d127e0188858", null ],
    [ "Goto", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a24cd8db03d0ea182c0d4c2322675e452", null ],
    [ "OpenAboutDialog", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#afd57bc7dcfa4dc9146d6affc3835f2de", null ],
    [ "OpenHelp", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a234656070a78f8e849bf00eb5d2a0af3", null ],
    [ "OpenSettingsDialog", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a661448de40b8637cd751b1143a462c4f", null ],
    [ "RefreshMasterData", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#ae52eaf75c9b3c2d0bc372359b4a26b34", null ],
    [ "ShowWelcomeScreen", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a2268eb78d4533d620e9a44ca447d14ed", null ],
    [ "Popup", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a7f5b062fc16fea2b672839843604d0cf", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#afeef3b14b762961b29ecd4cfbed53b4e", null ]
];