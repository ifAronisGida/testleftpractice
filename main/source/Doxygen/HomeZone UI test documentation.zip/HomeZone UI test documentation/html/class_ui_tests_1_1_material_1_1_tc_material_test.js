var class_ui_tests_1_1_material_1_1_tc_material_test =
[
    [ "DuplicateMaterialAndDeleteTest", "class_ui_tests_1_1_material_1_1_tc_material_test.html#ae4b8cd118cd344005c2c339fb56f3827", null ],
    [ "NewMaterialAndDeleteTest", "class_ui_tests_1_1_material_1_1_tc_material_test.html#a96e5d43d9bbea11e8a1f283fec0ef5dc", null ]
];