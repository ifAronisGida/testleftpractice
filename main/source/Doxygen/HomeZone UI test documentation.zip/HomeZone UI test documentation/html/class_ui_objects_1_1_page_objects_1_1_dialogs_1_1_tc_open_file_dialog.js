var class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_open_file_dialog =
[
    [ "SetFilename", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_open_file_dialog.html#a9a3cd00e5c887c4e61c55a80c6371b74", null ]
];