var interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders =
[
    [ "AddPartOrder", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#a70af3ff93e1fe6d117af5692333601a5", null ],
    [ "GetRow", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#a1be57a370f2990eebf7b40b4515bc2db", null ],
    [ "RemovePartOrder", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#a2e71b873d33c855f3bbc807c4dcff7be", null ],
    [ "SelectPartOrder", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#ae40304a9e5af3495e1651a016912f7a3", null ],
    [ "UnSelectAllPartOrders", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#a162e5f338f8d31a32ba0e1a374f182bf", null ],
    [ "PartOrdersCount", "interface_ui_object_interfaces_1_1_cut_job_1_1_ti_cut_job_contained_orders.html#a787fba80c8795c9787254d8dad3f8ea4", null ]
];