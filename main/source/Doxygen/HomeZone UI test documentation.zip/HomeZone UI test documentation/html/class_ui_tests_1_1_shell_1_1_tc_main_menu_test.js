var class_ui_tests_1_1_shell_1_1_tc_main_menu_test =
[
    [ "ExitTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#a9a02ca8c03d25e9f8e693c0ea94d71e4", null ],
    [ "OpenAndCloseSettingsTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#a884725657532a9f2655401e52762f5d2", null ],
    [ "RefreshMasterDataTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#ab9677721c87a3218b37e81421e59502d", null ],
    [ "ShowAboutTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#af4590f50df0b4920df30038aebb031ea", null ],
    [ "ShowHelpTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#aaf227a22e08f6cda180817c093218ac6", null ],
    [ "ShowWelcomeScreenTest", "class_ui_tests_1_1_shell_1_1_tc_main_menu_test.html#a2177444c2022be0eb2dfa7ea69c1f82c", null ]
];