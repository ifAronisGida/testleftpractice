var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_flux_1_1_tc_flux =
[
    [ "TcFlux", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_flux_1_1_tc_flux.html#aca714258a344742bf34ea7a7dee0717b", null ],
    [ "CloseApp", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a474b937f70413b57ff9668d057b695ab", null ],
    [ "MainWindowVisible", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_flux_1_1_tc_flux.html#aff533754beb8e1846365056bb9d87e2f", null ],
    [ "MenuFile", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_flux_1_1_tc_flux.html#a9f79c973d41380503dc19ccd8636af07", null ]
];