var interface_ui_object_interfaces_1_1_customer_1_1_ti_customers =
[
    [ "Apply", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a376bf51c852f385e8b5b0e7f43856dae", null ],
    [ "Cancel", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a6a89d0713d6fd0bfe227c7f45ba581c5", null ],
    [ "Count", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a6b3fbf3b053be6bbd09c062ba85fd30f", null ],
    [ "DeleteCustomer", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#aa4227ae491bd741d541c7218ec7b82b2", null ],
    [ "DeleteCustomersWithNameContaining", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a063e7cd16fb64dc2f3a212d9472accd2", null ],
    [ "DeleteSelectedCustomers", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a51ff4dcfbee8e99e10b2d7d58f626e01", null ],
    [ "Goto", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a53693a0666fd2ed4317cc70c4f2b187b", null ],
    [ "NewCustomer", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a9a0fdc692087f8a1f9dcf806c966f9e8", null ],
    [ "Select", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a2fae1dc64a3f8b527f04d6411392abeb", null ],
    [ "SelectCustomer", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a4ca3a03023483d6396d357c9e32a7153", null ],
    [ "SelectedCustomersCount", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a0c977338edc75ee2eeda6663e882d47f", null ],
    [ "SelectOnlyCustomersWithNameContaining", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a9a28ee71c4732d80af9f12108dbd3a54", null ],
    [ "City", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#ae94c8ef5d9f207a90303f9e9b562f41e", null ],
    [ "Comment", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#ade1b0dab41d096a39bbf2431ffe5a994", null ],
    [ "Country", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#afbdbedf2e1691c7fb8099781105cf370", null ],
    [ "Id", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a2e33db4cc29cbf9d256129e28240eb20", null ],
    [ "Name", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a0c923bf9b3304d1e26a024a83a27606a", null ],
    [ "PostalCode", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a46930998ce2ddf55a4d68e317b02c2e8", null ],
    [ "Street", "interface_ui_object_interfaces_1_1_customer_1_1_ti_customers.html#a932baa0bce60207ab27b05a00eded25a", null ]
];