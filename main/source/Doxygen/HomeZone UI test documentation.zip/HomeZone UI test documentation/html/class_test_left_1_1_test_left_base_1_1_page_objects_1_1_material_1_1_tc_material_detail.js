var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#ab7513521b48caac3b1395d7e4df70663", null ],
    [ "Abbreviation", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#ae822204c097d7840d76f611bb1fa0356", null ],
    [ "EModulus", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a14f58cb2b71fcd2d1711db9bba2f21b4", null ],
    [ "Id", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a4980f502de498b27ade849a934096865", null ],
    [ "Name", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a79af38b883ab5ecba514ff9a5a36b88d", null ],
    [ "SpecificWeight", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#ae98996bdd7c949baf22e949959c22cde", null ],
    [ "TensileStrength", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a5a1b6cc8f23da9958ba40455dcb6ca7f", null ],
    [ "TensileStrengthMax", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#abe82f1485bd379cf3d2319655e5f016f", null ],
    [ "TensileStrengthMin", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_material_1_1_tc_material_detail.html#a9cc72a1774edb395ab6657201f4fb1f5", null ]
];