var interface_ui_object_interfaces_1_1_material_1_1_ti_materials =
[
    [ "DeleteMaterial", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html#a973c638e7c6e488b9518d77df2ead719", null ],
    [ "WaitForDetailOverlayAppear", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html#a4ecef030b64a43b3957865cfa5e2a570", null ],
    [ "WaitForDetailOverlayDisappear", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html#a0ea750e302f41991ccc1d9d1e6c3e042", null ],
    [ "Detail", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html#aa4be1987c9ed65190ce41b49ccf9d234", null ],
    [ "Toolbar", "interface_ui_object_interfaces_1_1_material_1_1_ti_materials.html#a5cc82308a687c5b619bf0877d534bf7a", null ]
];