var class_test_left_1_1_u_i___tests_1_1_part_1_1_tc_part_test =
[
    [ "ImportDesignTest", "class_test_left_1_1_u_i___tests_1_1_part_1_1_tc_part_test.html#aafae7d81ee34ed12ab60578f60108a7e", null ],
    [ "ImportPartTest", "class_test_left_1_1_u_i___tests_1_1_part_1_1_tc_part_test.html#aa638491191abc9c356f558fcd7251b17", null ],
    [ "NewPartAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_part_1_1_tc_part_test.html#a727918172d04fb2bfeff44938d1cc771", null ],
    [ "TestEnvironment", "class_test_left_1_1_u_i___tests_1_1_part_1_1_tc_part_test.html#ab44e4bae290e63585178b1e2f66857a9", null ]
];