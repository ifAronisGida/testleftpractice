var class_test_left_1_1_u_i___tests_1_1_machine_1_1_tc_workplace_test =
[
    [ "NewBendMachineAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_machine_1_1_tc_workplace_test.html#a10eb3b72e9cf42abd22c77fa1f77dba0", null ],
    [ "NewCutMachineAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_machine_1_1_tc_workplace_test.html#a07e084431b3c924600edf252321ad2ff", null ]
];