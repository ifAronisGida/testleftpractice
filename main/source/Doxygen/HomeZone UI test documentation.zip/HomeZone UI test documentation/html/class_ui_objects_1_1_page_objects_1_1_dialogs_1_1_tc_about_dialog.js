var class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog =
[
    [ "Close", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#aa8b0711450ba3932024017150616c4ca", null ],
    [ "CopyToClipboard", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#a3c86c15a956dbe5dc9338768d8684bef", null ],
    [ "IsVisible", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#a28955d2debec8b7e20ccc861d6d9a877", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#ac43f054b4d9799701eacf8585e72f33e", null ]
];