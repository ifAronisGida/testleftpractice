var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail =
[
    [ "WaitForNameEnabled", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a286574215d9e701db96d1958318595c9", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ae404e46bab4de0ff986df94f91744571", null ],
    [ "Archivable", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a91106f6b3b2e75a996b7f5db74bc14ea", null ],
    [ "Customer", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ae7a2011d15002a84f6d54b353f6a48b9", null ],
    [ "DrawingNumber", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#afd7611d6a1cd3ee29dfb05b5f0ad0ec5", null ],
    [ "DrawingVersion", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ac09804a43c90168180ab69da53999bec", null ],
    [ "ExternalName", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a871f9c1affdea8643c69be27ba3c99ca", null ],
    [ "Id", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#ad8e6c704c944db342e5bbcc57265bce2", null ],
    [ "IsMoreExpanded", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a7ccb0b1793962a22909d404e5eba9b53", null ],
    [ "Name", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#af2428629fa8b58b002c404f983a6467d", null ],
    [ "Note", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail.html#a714398a6d603a4de073f812e54f58a6d", null ]
];