var interface_ui_object_interfaces_1_1_dialogs_1_1_ti_message_box =
[
    [ "MessageBoxExists", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_message_box.html#a1420c2f1892914cfd4a820064072a03f", null ],
    [ "Yes", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_message_box.html#ad6ce2f53f5280385e2b716baf894f57c", null ]
];