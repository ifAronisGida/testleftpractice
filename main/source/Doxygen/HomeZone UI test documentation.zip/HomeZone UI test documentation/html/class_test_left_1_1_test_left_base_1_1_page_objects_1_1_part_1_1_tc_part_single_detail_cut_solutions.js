var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions =
[
    [ "New", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#ada0e7c47ee4a0807e600075e7aea046a", null ],
    [ "OpenCutSolution", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#aff3fe1433afd65fd941a0e6296de9067", null ],
    [ "Count", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#a0cbc8365e422573923c7ac8c440b7bb9", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#a7cd0b2ec46cff6936ed4e17f54fd870f", null ]
];