var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers =
[
    [ "ApplyClick", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a8a3251b39f8a2e834cbc521909dc8fef", null ],
    [ "CancelClick", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a5bc32d15730b6a4c8e4d230b3cec80a9", null ],
    [ "CleanUp", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a16eaaba3dbc0a977703b2e2ae5dd372e", null ],
    [ "Count", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a19ac2cb798c2aa137d09f20b1d4e187c", null ],
    [ "DeleteCustomerClick", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#af9b53baa223a580ecce8992c494b7739", null ],
    [ "DeleteCustomersWithNameContaining", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a0fb2c26906576441730984fabe8397f9", null ],
    [ "Goto", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a81cabca5e67bd3236eebc17923298529", null ],
    [ "NewCustomer", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a5b6b35eee0803f7abc74edc28eb88fef", null ],
    [ "NewCustomerClick", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ad76d2d66a81d8187354166512f545810", null ],
    [ "SelectClick", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a916fe6998b0b198921361218d9dd53f2", null ],
    [ "SelectCustomer", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#adb9fc030741c998cada486145ebed9e0", null ],
    [ "SelectedCustomersCount", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a3d310a5acd0a2f824cc046c0de128248", null ],
    [ "SelectOnlyCustomersWithNameContaining", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#adda3ba4db878adf3992ff845b0b4346d", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#ae71ac29261db64580ae925fa91aec3ec", null ],
    [ "Address", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a525cdca875b6c1017c1895cb1de65dba", null ],
    [ "City", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#aa6d8a920b524fb6a25af3f14cdd86bb3", null ],
    [ "Comment", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a6a3a26b8c5b93e30fb06f9f547afd4a3", null ],
    [ "Country", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a574fc1ce345d7fd73bc4e2484025d680", null ],
    [ "ID", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#a925e33306590b17d3f62a3d428471645", null ],
    [ "Name", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#aa7cf9cc91bf1e2f41377f112739bb0be", null ],
    [ "PostalCode", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html#af33bd8e1bf598ed541b0ccdc41038c91", null ]
];