var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu =
[
    [ "NewBendMachineButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#ad5a82c8ab2f693db9e7d4279ca578043", null ],
    [ "NewCutMachineButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#a18ca14a4da177be762233427fbc1ebf6", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_popup_menu.html#a2c4596e5da60b640dc0611ae0900889d", null ]
];