var class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design =
[
    [ "Import", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#addb27c3263972c33306895d7f5e7e788", null ],
    [ "Open", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#afe9c9b734556ff608614ede737756761", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_design.html#a29679d70cfa3c783600dd554dfb1ebfa", null ]
];