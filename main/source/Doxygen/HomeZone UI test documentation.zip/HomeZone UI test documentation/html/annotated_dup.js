var annotated_dup =
[
    [ "SmokeTests", "namespace_smoke_tests.html", "namespace_smoke_tests" ],
    [ "TestLeft", "namespace_test_left.html", "namespace_test_left" ],
    [ "UiObjectInterfaces", "namespace_ui_object_interfaces.html", "namespace_ui_object_interfaces" ],
    [ "UiObjects", "namespace_ui_objects.html", "namespace_ui_objects" ],
    [ "UiTests", "namespace_ui_tests.html", "namespace_ui_tests" ]
];