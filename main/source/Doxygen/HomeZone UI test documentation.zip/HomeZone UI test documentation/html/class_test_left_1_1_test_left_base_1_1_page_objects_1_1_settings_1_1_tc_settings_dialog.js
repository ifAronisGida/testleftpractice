var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog =
[
    [ "TcSettingsDialog", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#ae0ae9e65af2d80b12373b7462b8f5ccd", null ],
    [ "Cancel", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a9cf7a55ef0e6e637c7a16e9cbcdfd3f1", null ],
    [ "Goto", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a776a65f42cab6152c83a6887987e9cef", null ],
    [ "Save", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#ab36286221c520f22c41a07e210e33ed4", null ],
    [ "BendSettings", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a32642b21e1cecba9d7bde52a49c9eae7", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a33a8c1967daafc6c352ac75c9d04a271", null ]
];