var interface_ui_object_interfaces_1_1_dialogs_1_1_ti_help_dialog =
[
    [ "Close", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_help_dialog.html#af70752bbccbd6d45ef6c559e97802d32", null ]
];