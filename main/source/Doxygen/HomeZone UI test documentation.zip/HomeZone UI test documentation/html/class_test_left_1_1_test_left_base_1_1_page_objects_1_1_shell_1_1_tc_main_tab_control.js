var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control =
[
    [ "AddNewTab", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#a15141eb89c84146c51da2a1f42569b80", null ],
    [ "CloseCurrentTab", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#a88594b49369f857a6723ba9ac5fe3543", null ],
    [ "Count", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#a43852efef65f36fca3ce37983aeebf52", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#ad8389267d9d84b575ba9933b57d77919", null ],
    [ "SelectedIndex", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#ae5b619356c94aab15299b1c10573ff93", null ]
];