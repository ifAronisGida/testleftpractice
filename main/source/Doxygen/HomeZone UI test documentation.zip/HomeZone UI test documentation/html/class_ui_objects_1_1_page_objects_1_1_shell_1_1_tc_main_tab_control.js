var class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control =
[
    [ "AddNewTab", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#affd5c64fcfb51c8696b1acd244dbde10", null ],
    [ "CloseCurrentTab", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#adfd0f560062609d12b4bbdae8a8908cc", null ],
    [ "Count", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#adff8f0122b75ba36a3856e9b9b1284f3", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#a4cadb46e7260e596088a1cdc223cbbe6", null ],
    [ "SelectedIndex", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_tab_control.html#aa3a363321371664a835f5d5344a9b61c", null ]
];