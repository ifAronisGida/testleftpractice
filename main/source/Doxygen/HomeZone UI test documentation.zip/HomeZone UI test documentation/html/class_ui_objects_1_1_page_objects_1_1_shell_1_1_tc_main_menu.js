var class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu =
[
    [ "TcMainMenu", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#af8fc983b304ec8c1e014fcf81d9adf9f", null ],
    [ "CloseApplication", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a94e54b05b8da53db3290a5200d1482f8", null ],
    [ "Goto", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#adedb14da14f40bec94a634e2675ec6fc", null ],
    [ "OpenAboutDialog", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#af46dc82290c2dfa2f5e168b1b05a12fa", null ],
    [ "OpenHelp", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#aa39692aada38b112270b77eec644ba85", null ],
    [ "OpenSettingsDialog", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a6732e161bc01b45a754de4ad4a76615f", null ],
    [ "RefreshMasterData", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#aa158480839e0b40eac9857871243008c", null ],
    [ "ShowWelcomeScreen", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a24394ee6e4c88088cb4cb2262d703ee0", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_shell_1_1_tc_main_menu.html#a0943cd70b8a4de9456ee25da929d0b56", null ]
];