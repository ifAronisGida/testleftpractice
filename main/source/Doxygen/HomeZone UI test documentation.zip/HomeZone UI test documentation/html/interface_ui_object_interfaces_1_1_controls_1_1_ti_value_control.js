var interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control =
[
    [ "IsReadOnly", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html#acddd84aac8f4074e1022494ab7b8f013", null ],
    [ "Value", "interface_ui_object_interfaces_1_1_controls_1_1_ti_value_control.html#ae7aec692232b388508a42946101baa9e", null ]
];