var class_ui_tests_1_1_part_order_1_1_tc_part_order_test =
[
    [ "NewPartOrderAndDeleteTest", "class_ui_tests_1_1_part_order_1_1_tc_part_order_test.html#a4e98ec0a5742bbb742b6bf223855ab9f", null ],
    [ "SelectPartIntoOrderTest", "class_ui_tests_1_1_part_order_1_1_tc_part_order_test.html#a130504c4a219b7df13e3e99b113e0682", null ]
];