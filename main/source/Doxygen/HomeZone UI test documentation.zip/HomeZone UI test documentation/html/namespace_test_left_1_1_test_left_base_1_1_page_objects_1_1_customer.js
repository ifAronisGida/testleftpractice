var namespace_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer =
[
    [ "TcCustomers", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers.html", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_customer_1_1_tc_customers" ]
];