var interface_ui_object_interfaces_1_1_cut_1_1_ti_t_t_selection_dialog =
[
    [ "Close", "interface_ui_object_interfaces_1_1_cut_1_1_ti_t_t_selection_dialog.html#ad6a65003410520410c5a65a9223e517d", null ],
    [ "IsDialogVisible", "interface_ui_object_interfaces_1_1_cut_1_1_ti_t_t_selection_dialog.html#a2525a74ac3b9da10e2a8749d5d42c713", null ]
];