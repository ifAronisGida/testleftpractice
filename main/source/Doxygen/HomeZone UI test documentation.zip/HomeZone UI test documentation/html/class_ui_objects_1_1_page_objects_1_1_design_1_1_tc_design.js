var class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design =
[
    [ "TcDesign", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design.html#a724a6d3883974fee459501b89231cdf2", null ],
    [ "CloseApp", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design.html#a41f60b1f3545882f6f1a219eeebd9784", null ],
    [ "IsMainWindowVisible", "class_ui_objects_1_1_page_objects_1_1_design_1_1_tc_design.html#a1ac5f6275644d968625b87ecd3ebc29f", null ]
];