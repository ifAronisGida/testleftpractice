var class_test_left_1_1_u_i___tests_1_1_cut_job_1_1_tc_cut_job_test =
[
    [ "NewCutJobAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_cut_job_1_1_tc_cut_job_test.html#a9446a8b6dde6393e559226f5abe745b1", null ],
    [ "OrdersTableTest", "class_test_left_1_1_u_i___tests_1_1_cut_job_1_1_tc_cut_job_test.html#a0ea28a2fe546c614e20f319c69c7d997", null ],
    [ "RawMaterialSelectionTest", "class_test_left_1_1_u_i___tests_1_1_cut_job_1_1_tc_cut_job_test.html#a9a19d5fba2baab0d676ce950cbb78427", null ],
    [ "RawSheetsTest", "class_test_left_1_1_u_i___tests_1_1_cut_job_1_1_tc_cut_job_test.html#a044aea3b525fb177e4639843390e13ee", null ]
];