var class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux_configure_machine =
[
    [ "TcFluxConfigureMachine", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux_configure_machine.html#a74a1f617faa7c0319ed25ffbdbfb52dc", null ],
    [ "CloseMachienDialog", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux_configure_machine.html#a6740f79f4da4b22da9e5b3607d7785e5", null ],
    [ "MachineDialogVisible", "class_ui_objects_1_1_page_objects_1_1_flux_1_1_tc_flux_configure_machine.html#a0f9d38bddd89a0d67a3db5139d2c28f9", null ]
];