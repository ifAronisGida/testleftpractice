var class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_read_only_text =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_read_only_text.html#a7477be45615b16aa95416b349b8036a2", null ],
    [ "Text", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_read_only_text.html#aef2cbed63b145f60c959332067af7ff7", null ]
];