var class_ui_tests_1_1_shell_1_1_tc_shell_test =
[
    [ "Add10Tabs", "class_ui_tests_1_1_shell_1_1_tc_shell_test.html#a66ae62b2af559750f075fafeea0ebd0a", null ],
    [ "Add10TabsWithPartSelected", "class_ui_tests_1_1_shell_1_1_tc_shell_test.html#adc06eb34e71c12683acc487d5ea8b768", null ],
    [ "AddTab", "class_ui_tests_1_1_shell_1_1_tc_shell_test.html#a9f31e08eac2b67a498374d52a41ad0be", null ],
    [ "CloseAllAdditionalTabs", "class_ui_tests_1_1_shell_1_1_tc_shell_test.html#ae78ca85a20a5f4b4ca6bdcfa623e13fe", null ]
];