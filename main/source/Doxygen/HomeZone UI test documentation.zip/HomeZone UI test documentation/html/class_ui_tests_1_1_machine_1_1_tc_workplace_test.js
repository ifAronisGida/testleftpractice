var class_ui_tests_1_1_machine_1_1_tc_workplace_test =
[
    [ "NewBendMachineAndDeleteTest", "class_ui_tests_1_1_machine_1_1_tc_workplace_test.html#a1e9fb68dd70f5d8b8473f6a1f435133b", null ],
    [ "NewCutMachineAndDeleteTest", "class_ui_tests_1_1_machine_1_1_tc_workplace_test.html#a853d14339da1b4b2780c901f6d8b4da8", null ]
];