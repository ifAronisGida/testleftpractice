var interface_ui_object_interfaces_1_1_dialogs_1_1_ti_open_file_dialog =
[
    [ "SetFilename", "interface_ui_object_interfaces_1_1_dialogs_1_1_ti_open_file_dialog.html#a72e5fe9a4a202a3eba8adc777417d37d", null ]
];