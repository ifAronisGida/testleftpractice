var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines =
[
    [ "TcMachines", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#af729e0a726e9a41831b29425091e2dcf", null ],
    [ "DeleteMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#af2b0c1f0ed570abc3dd603af50d3b54d", null ],
    [ "Goto", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a32c5a5d4dc97222a6db10c693d9a2dea", null ],
    [ "NewBendMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a973061f66d411afd7e412e5470e66549", null ],
    [ "NewBendMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ab01afa4184d17835cf7925254604c637", null ],
    [ "NewCutMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ab9d8f297cbc8380ba76d84a898b74a8b", null ],
    [ "NewCutMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#aed1e94be1a901ef995c7d8a287498cbc", null ],
    [ "NewCutMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#aa3ffe91eb78a834d2deb1b08513fcd7b", null ],
    [ "SaveMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a7dbdb70da890aae47fe6218ad7335b31", null ],
    [ "SelectAll", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a9459c3b053bd80db607b0d177e159e8d", null ],
    [ "SelectMachine", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#aff9660f3622c441897ca9b3e67720e82", null ],
    [ "SelectMachines", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ac34da02cc90951fe3a5d6de7c16c7fcb", null ],
    [ "WaitForDetailOverlayAppear", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a437b85bd67fa66b4801013e3d84c9dc5", null ],
    [ "WaitForDetailOverlayDisappear", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#af58417f2bfe16d4e5efdd4a8b2417241", null ],
    [ "Detail", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a1f1f2dec2b6674345b12b7d4375d36d9", null ],
    [ "DetailOverlay", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a40bfa2a5fec59da14acaba616a0a83db", null ],
    [ "Popup", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#ad20867ae228462774d4445dc0d3a9f02", null ],
    [ "ResultColumn", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#aaaf11710439a60a9169dc2e1508e26b7", null ],
    [ "Toolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machines.html#a67f14dfdb177764e94c35f073c27ca11", null ]
];