var class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar =
[
    [ "Delete", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#aac66d8e037c0c8e9255c708f16beb30b", null ],
    [ "NewBendMachine", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a318005debc9235a9238b3c95ad64333d", null ],
    [ "NewCutMachine", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#acbd727c88430d0f0e3c068fafd9f37f1", null ],
    [ "Save", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a182d75eda464365b78f479a89ff3ccf4", null ],
    [ "CanDelete", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a5e4f32f1a22bf611ac9b0315a6ed90f2", null ],
    [ "CanRevert", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a30369077d8329f224ed784e6d15dde50", null ],
    [ "CanSave", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a5bd1d4642312b332640382e0b829ca0f", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#ae8ff35a524d7add8a6f30c767b342b1c", null ]
];