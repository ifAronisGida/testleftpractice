var class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_spin_edit =
[
    [ "Value", "class_test_left_1_1_test_left_base_1_1_control_objects_1_1_tc_spin_edit.html#ac068ab011984a14d5f32e10aad852548", null ]
];