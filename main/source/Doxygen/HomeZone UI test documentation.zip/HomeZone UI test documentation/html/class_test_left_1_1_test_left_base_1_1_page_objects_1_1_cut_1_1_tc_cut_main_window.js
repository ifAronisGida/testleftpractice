var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_main_window =
[
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_1_1_tc_cut_main_window.html#a372eb93909cfaeb1462723aedec7210e", null ]
];