var class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog =
[
    [ "TcSettingsDialog", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#afe4d3aa9c759517edf8e71421972da35", null ],
    [ "Cancel", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#aa0f30c96d5d5d1e0a875d73588611260", null ],
    [ "Goto", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a158294aaa23ad2339a4304c8d2b1f36f", null ],
    [ "Save", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a2d25620c7e4ea6624e3cd7593563afbe", null ],
    [ "BendSettings", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#ab6a171f89ccb2d75937f5ce890549b8c", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_settings_1_1_tc_settings_dialog.html#a2163982206f25623a949ff2c004aaee5", null ]
];