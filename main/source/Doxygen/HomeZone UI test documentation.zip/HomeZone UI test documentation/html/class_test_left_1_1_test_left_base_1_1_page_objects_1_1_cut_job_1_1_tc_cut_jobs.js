var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs =
[
    [ "TcCutJobs", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a0b1665967aca00be3f41bee0c0b250de", null ],
    [ "DeleteCutJob", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#ad850beca4f0f9a153f80ce8bb07cfefa", null ],
    [ "Goto", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a6b56a88bd284751a9200b542cee81618", null ],
    [ "NewCutJob", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#adaa1c8e1d470cdaecd2612c2a2afb194", null ],
    [ "RevertCutJob", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#ab64f92aab6e8cc4a8739f9704e993c21", null ],
    [ "SaveCutJob", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a1c99ed6f32efcfb43e3c8170f5e3b817", null ],
    [ "SelectAll", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#aaecd5033fcb8ddd7f175a0a29692f5d2", null ],
    [ "SelectCutJob", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#ac1f28bd68e41e48bcc3297a04a0324f8", null ],
    [ "SelectCutJobsOrders", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#af5e60c26bd6d891df8f2e488576db5b8", null ],
    [ "ContainedOrders", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a147454e7499978e2e261d7b557d7ba54", null ],
    [ "ResultColumn", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a1fb9f4bcefd541e4c781d6b94ad70c72", null ],
    [ "SingleDetail", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a9131618c81610cc485edcea536cee204", null ],
    [ "Toolbar", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#aa9f2b16107cebd639b218873c1c37f60", null ],
    [ "CutJobSolution", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_cut_job_1_1_tc_cut_jobs.html#a36944471f202428f4f0e577b3cb17bd8", null ]
];