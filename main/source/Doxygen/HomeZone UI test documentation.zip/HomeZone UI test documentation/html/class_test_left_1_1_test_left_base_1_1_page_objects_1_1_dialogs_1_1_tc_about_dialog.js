var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog =
[
    [ "Close", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#a4811c2f6eb603d05d72b6daeec3881a4", null ],
    [ "CopyToClipboard", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#a7b7bb2ae13aebb3fed5404c5d54f1c90", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_dialogs_1_1_tc_about_dialog.html#a776a3f355094ba02d003615255bee314", null ]
];