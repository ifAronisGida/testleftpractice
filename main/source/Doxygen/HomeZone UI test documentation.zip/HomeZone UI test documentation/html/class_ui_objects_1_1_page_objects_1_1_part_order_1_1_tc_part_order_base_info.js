var class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info =
[
    [ "Customer", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a017112d8735cb727a555fca78e62f78c", null ],
    [ "CustomerOrderNumber", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a2614d8eebea44d87fb28c7308ade37c4", null ],
    [ "ExternalAssembly", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a2706c1b9ef7eda55323f128e9c101fc8", null ],
    [ "FinishDate", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a139a9929f2e551a5900feda926e796dd", null ],
    [ "ID", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#ac6555580b653bbdb3ace08b21c56a94e", null ],
    [ "IsArchivable", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a87ba0018bc9eca006ce890dfc38b0a3f", null ],
    [ "IsFiller", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#ab50db5a9b4c8d6292051876bb88bb615", null ],
    [ "OrderCategory", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#ade21f1fcad714110f11ef6c05c18d8cd", null ],
    [ "Quantity", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#a86320d18e88b8bee1232ce37e8047059", null ],
    [ "RawMaterial", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#aff507f474376970415d882d2314ff383", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_order_1_1_tc_part_order_base_info.html#abfa52df33624ac318a5c30dba061b64a", null ]
];