var class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions =
[
    [ "New", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#aa8a1bc0cb5d20a4a1aecdc2ca353cf90", null ],
    [ "OpenCutSolution", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#a59d66d23a2a1af837a2978de715d66c0", null ],
    [ "Count", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#a26f0f811446c0a907adc73a3f00bf0f3", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_part_single_detail_cut_solutions.html#ae6d5729678e4f81d4da603bddab18bd5", null ]
];