var class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar =
[
    [ "DeleteButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a3a22bdb7637cb0c225e545815a88a0a1", null ],
    [ "NewBendMachineButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#acde98892d39c7c4241d17442118ff47d", null ],
    [ "NewCutMachineButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a3e1ef199d240f9f3ec31561bbee92a8d", null ],
    [ "NewMachineButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#ad7515bfef1c3d61e3b3675a87437b838", null ],
    [ "RevertButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#afc01d0ef8d1a3173216b23b8d35916ce", null ],
    [ "SaveButton", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a84fcf1019135474818f370a137b15f46", null ],
    [ "SearchPattern", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a75de1af06abf476d9fa9fc58ac3e1f22", null ],
    [ "Process", "class_test_left_1_1_test_left_base_1_1_page_objects_1_1_machine_1_1_tc_machine_toolbar.html#a14adfe8397bee41123c2d5c3b66eee5b", null ]
];