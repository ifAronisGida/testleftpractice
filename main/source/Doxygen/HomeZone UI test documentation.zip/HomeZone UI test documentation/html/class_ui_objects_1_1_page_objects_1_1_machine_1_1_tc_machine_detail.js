var class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail =
[
    [ "OpenMachineConfigurationBend", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#ad9d06226de9f0d06c5f163e77ed1ec09", null ],
    [ "CreateSubDirectory", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#aca39ad5816fe33dcd3d1c9ba69fea75c", null ],
    [ "LaserPower", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a28b7c9ac8a51beb4520dff7512dda60e", null ],
    [ "MachineNumber", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#aa121baf960f80825cf59c346bde304e3", null ],
    [ "Name", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a5124c237791c4387cbf6b88c026c5d38", null ],
    [ "SearchPattern", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a9a78afb9fdc814dc7e6c69a4caf34e98", null ],
    [ "TransferDirectory", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#ac8f5a96d4f40dcf925c84951f09ee55a", null ],
    [ "BendMachineType", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a4b06801c161ae6138450fe198ec1ec15", null ],
    [ "CutMachineType", "class_ui_objects_1_1_page_objects_1_1_machine_1_1_tc_machine_detail.html#a49822fdc3f24ed69552511941c0f15d6", null ]
];