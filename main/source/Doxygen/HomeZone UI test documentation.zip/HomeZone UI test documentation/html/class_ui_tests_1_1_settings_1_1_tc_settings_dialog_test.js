var class_ui_tests_1_1_settings_1_1_tc_settings_dialog_test =
[
    [ "OpenAndCloseSettingsTest", "class_ui_tests_1_1_settings_1_1_tc_settings_dialog_test.html#af3b6720015f134afa8f1f2c761a53e58", null ]
];