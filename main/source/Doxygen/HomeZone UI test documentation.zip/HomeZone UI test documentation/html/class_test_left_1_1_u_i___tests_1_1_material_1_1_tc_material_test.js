var class_test_left_1_1_u_i___tests_1_1_material_1_1_tc_material_test =
[
    [ "DuplicateMaterialAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_material_1_1_tc_material_test.html#aef6ae234e4e08c8ada29fd289c329eea", null ],
    [ "NewMaterialAndDeleteTest", "class_test_left_1_1_u_i___tests_1_1_material_1_1_tc_material_test.html#ab629fb4931b96d82fe4d721b27c29dc1", null ]
];