var class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts =
[
    [ "DeletePart", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#ad2d87a00d4c5d352e081fbd1a8d2d9af", null ],
    [ "DoGoto", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#aa16993a8e77b23fca7d3315f1c192428", null ],
    [ "WaitForDetailOverlayAppear", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#a5e9db2cd5c703adf4c6d35f45decdb35", null ],
    [ "WaitForDetailOverlayDisappear", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#ad6d0f158e396a95738d8dae7694b452b", null ],
    [ "SingleDetail", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#aabf69237e7ca577b271bf6cf10031126", null ],
    [ "SingleDetailBendSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#a075f94e4173b8d940046c1bd30344bf0", null ],
    [ "SingleDetailCutSolutions", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#a7e762b20ec368f17e3ba396532204652", null ],
    [ "SingleDetailDesign", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#afda7b3aacc9cd8db2d7bceddeca5e274", null ],
    [ "Toolbar", "class_ui_objects_1_1_page_objects_1_1_part_1_1_tc_parts.html#a5b606611936071817e127d86c83fdcf3", null ]
];