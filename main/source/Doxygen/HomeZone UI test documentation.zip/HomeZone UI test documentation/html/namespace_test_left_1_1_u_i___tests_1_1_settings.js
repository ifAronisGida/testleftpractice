var namespace_test_left_1_1_u_i___tests_1_1_settings =
[
    [ "TcBendSettingsTest", "class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_bend_settings_test.html", "class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_bend_settings_test" ],
    [ "TcSettingsDialogTest", "class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_settings_dialog_test.html", "class_test_left_1_1_u_i___tests_1_1_settings_1_1_tc_settings_dialog_test" ]
];