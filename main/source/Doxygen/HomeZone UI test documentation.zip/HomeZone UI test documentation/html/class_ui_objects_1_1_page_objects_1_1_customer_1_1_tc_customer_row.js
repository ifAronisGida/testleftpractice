var class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row =
[
    [ "TcCustomerRow", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#aea2bcb569795a60c772365714ca5e386", null ],
    [ "City", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#aaba01bd55f399e9dc1799b217133606f", null ],
    [ "Country", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#a6538bda60104107bdc6fe14504ad64c2", null ],
    [ "ID", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#a5eb3b6b0334b2fc3a7a131215bff9a19", null ],
    [ "Name", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#a40bed86973500fd3dfdc13f3f258e1c5", null ],
    [ "Note", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#ab365683d4b5ce386bd71b78bf086e20a", null ],
    [ "PostalCode", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#a07725bec649eed65cbdad9e1f6b6f842", null ],
    [ "Street", "class_ui_objects_1_1_page_objects_1_1_customer_1_1_tc_customer_row.html#ad785a1653994f3d1d1bd00fdcf2a4753", null ]
];