var class_ui_objects_1_1_tc_app =
[
    [ "TcApp", "class_ui_objects_1_1_tc_app.html#a71bd29b9e05383f8f9ce7305f79ed988", null ],
    [ "CloseApp", "class_ui_objects_1_1_tc_app.html#a9b717a60ee4d324eb42ca4e57364ff54", null ],
    [ "IsMainWindowVisible", "class_ui_objects_1_1_tc_app.html#a067b766df30a41594df785d65f475608", null ],
    [ "Driver", "class_ui_objects_1_1_tc_app.html#a8e217d357ef3f0454c11b51d7ec871a5", null ]
];