var class_ui_tests_1_1_design_1_1_tc_design_test =
[
    [ "DesignOpenCloseTest", "class_ui_tests_1_1_design_1_1_tc_design_test.html#a1b22cf33c66af3c530558bf9455fffaf", null ],
    [ "DoDesignOpenClose", "class_ui_tests_1_1_design_1_1_tc_design_test.html#af2257c5cf68e0cdef6366ef9c45f04e6", null ]
];